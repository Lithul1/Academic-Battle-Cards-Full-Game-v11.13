# Handoff: book sub-screens (fix_menu_pages.py)

This is the approved preview. It's CSS only, inserted as a single block before `</head>`. No markup or behaviour changes. It needs no other patch, but it's designed to sit alongside fix_menu_book and fix_menu_book2.

## Screens
- **Changed:** Difficulty, Custom Play, Pagemaster picker, House Rules, PreCon Arena setup, Challenges, Quickstart Guide, Tutorial.
- **Untouched (per Trevor):** Literary Scrimmage and the Deck Builder.

## Look
- **The page:**
  - one book page on the dark table, with a gutter shadow and stacked page edges
  - a running head, set per screen through `--ss-head` on `body[data-menuscreen]`
  - a page number at the bottom, set through `--ss-pg`
- **"‹ Back to menu"** sits in the top left of the page. It's the existing `[data-do=menu]` button, restyled.
- **Logo:** the small logo is hidden on inner pages.
- **Choice cards:** difficulty and Arena deck choices are ruled index cards. The selected one gets a gold ring and a "✓ chosen" tag.
- **House Rules:** a ruled ledger. On phone, rows wrap and the panel is held to the page width (it used to overflow by 1px).
- **Buttons:** the main action uses teal `.bigbtn`. Other buttons use paper and ink `.toolbtn`, with on-state toggles in black and gold.
- **Guide:** text sits directly on the page.

## Performance
- No images and no JS.
- These screens no longer draw the full-screen background art or the logo.
- Only short hover transitions, turned off by reduced motion.

## Tests
- `test_menu_pages.py`: 42 checks on desktop and phone. Every screen is checked for:
  - a paper page on the dark table
  - no background image or logo
  - no sideways scroll
  - the running head and page number
- It also checks that Back to menu sits in the top left and works, that the chosen difficulty is tagged, and that the Deck Builder is untouched.
