import asyncio
import os, pathlib
_ROOT = pathlib.Path(__file__).resolve().parents[2]
STUB_URL = (pathlib.Path(os.environ.get('ABC_STUB', _ROOT / 'dist' / 'stub.html')).resolve()).as_uri()
_CHROME = os.environ.get('ABC_CHROME')
def _launch_kw(): return {'executable_path': _CHROME} if _CHROME else {}
from playwright.async_api import async_playwright

SCR = [('difficulty', "A.mode='custom'", 'Before the first page'), ('custom', "A.mode='custom'", 'Chapter II · Custom Play'),
       ('pmpick', "A.mode='pagemaster'; A.drawnMode=true; A.pmCommanders=[]", 'Chapter III · Pagemaster'), ('tune', "", 'House Rules'),
       ('arena', "A.mode='arena'", 'Chapter IV · PreCon Arena'), ('challenges', "", 'Chapter VI · Challenges'),
       ('guide', "", 'Chapter IX · Quickstart Guide'), ('tutorial', "", 'Chapter X · The Tutorial')]
PAGE = """(()=>{ const p=document.querySelector('#game .title-screen.sub-screen'); if(!p) return null; const cs=getComputedStyle(p), b=getComputedStyle(document.body,'::before');
  const logo=p.querySelector('.title-logo'); const r=p.getBoundingClientRect();
  return {bg:cs.backgroundColor, head:getComputedStyle(p,'::before').content, pg:getComputedStyle(p,'::after').content, table:b.backgroundColor, img:b.backgroundImage.indexOf('url(')>=0,
    logo:!logo||getComputedStyle(logo).display==='none', w:r.width, left:r.left, sw:document.documentElement.scrollWidth}; })()"""

async def main():
  async with async_playwright() as p:
    b = await p.chromium.launch(**_launch_kw())
    res = []; ok = lambda n, c: res.append(('PASS' if c else 'FAIL') + '  ' + n)
    for vw, vh, touch, t in [(1280, 800, False, 'desk'), (390, 844, True, 'phone')]:
      ctx = await b.new_context(viewport={'width': vw, 'height': vh}, has_touch=touch, is_mobile=touch); pg = await ctx.new_page()
      errs = []; pg.on('pageerror', lambda e: errs.append(str(e)))
      await pg.goto(STUB_URL); await pg.wait_for_timeout(900)
      for k, setup, head in SCR:
        await pg.evaluate(f"(()=>{{ const A=ABC_DEBUG.APP; {setup}; A.screen='{k}'; ABC_DEBUG.render(); }})()"); await pg.wait_for_timeout(150)
        d = await pg.evaluate(PAGE)
        good = bool(d) and d['bg'] == 'rgb(246, 238, 219)' and d['table'] == 'rgb(43, 38, 32)' and not d['img'] and d['logo'] and d['sw'] <= vw
        ok(f'{t} {k}: a book page on the dark table, no background image or logo, no sideways scroll', good)
        ok(f'{t} {k}: running head "{head}" + page number', bool(d) and d['head'] == '"' + head + '"' and d['pg'].startswith('"—'))
      # back link: top-left of the page, says Back to menu, still works
      await pg.evaluate("(()=>{ const A=ABC_DEBUG.APP; A.mode='custom'; A.screen='difficulty'; ABC_DEBUG.render(); })()"); await pg.wait_for_timeout(150)
      bk = await pg.evaluate("""(()=>{ const p=document.querySelector('.sub-screen').getBoundingClientRect(), e=document.querySelector('.sub-screen [data-do="menu"]'), r=e.getBoundingClientRect();
        return [r.top-p.top, r.left-p.left, getComputedStyle(e,'::after').content]; })()""")
      ok(f'{t} "Back to menu" sits top left of the page ({bk[0]:.0f},{bk[1]:.0f})', 0 <= bk[0] < 40 and 0 <= bk[1] < 60 and bk[2] == '"‹ Back to menu"')
      ok(f'{t} chosen difficulty is tagged', await pg.evaluate("getComputedStyle(document.querySelector('.diff-card.on'),'::after').content.indexOf('chosen')>=0"))
      sel = '.sub-screen [data-do="menu"]'
      if touch: await pg.tap(sel)
      else: await pg.click(sel)
      await pg.wait_for_timeout(250)
      ok(f'{t} Back to menu returns to the menu', await pg.evaluate("ABC_DEBUG.APP.screen") == 'menu')
      # untouched screens
      await pg.evaluate("document.body.classList.add('calm-fx'); document.querySelector('[data-do=builder]').click(); document.body.classList.remove('calm-fx')"); await pg.wait_for_timeout(300)
      ok(f'{t} Deck Builder is untouched', await pg.evaluate("!document.querySelector('#game .title-screen.sub-screen') || getComputedStyle(document.querySelector('#game .title-screen.sub-screen'),'::before').content==='none'"))
      ok(f'{t} no page errors', not errs)
      await ctx.close()
    print('\n'.join(res)); print(sum(r.startswith('PASS') for r in res), '/', len(res)); globals()['_FAILS'] = sum(r.startswith('FAIL') for r in res); await b.close()
asyncio.run(main())
import sys; sys.exit(1 if globals().get('_FAILS') else 0)
