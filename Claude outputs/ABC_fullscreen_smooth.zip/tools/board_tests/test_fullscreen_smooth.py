import asyncio, os, pathlib
_ROOT = pathlib.Path(__file__).resolve().parents[2]
STUB_PATH = pathlib.Path(os.environ.get('ABC_STUB', _ROOT / 'dist' / 'stub.html')).resolve()
STUB_URL = STUB_PATH.as_uri()
_CHROME = os.environ.get('ABC_CHROME')
def _launch_kw(): return {'executable_path': _CHROME} if _CHROME else {}
from playwright.async_api import async_playwright

SLOW = """(ms=>new Promise(res=>{ const t0=performance.now(); (function f(){ const a=performance.now(); while(performance.now()-a<100){} if(performance.now()-t0<ms) requestAnimationFrame(f); else res(); })(); }))"""

async def battle(pg):
  await pg.evaluate("ABC_DEBUG.startBattle()"); await pg.wait_for_timeout(3000)
  await pg.evaluate("ABC_DEBUG.freeze(); ABC_DEBUG.busy=false; ABC_DEBUG.render()"); await pg.wait_for_timeout(200)

async def main():
  async with async_playwright() as p:
    b = await p.chromium.launch(**_launch_kw())
    res = []; ok = lambda n, c: res.append(('PASS' if c else 'FAIL') + '  ' + n)
    # ---------- desktop ----------
    ctx = await b.new_context(viewport={'width': 1280, 'height': 720}); pg = await ctx.new_page()
    errs = []; pg.on('pageerror', lambda e: errs.append(str(e)))
    await pg.goto(STUB_URL); await pg.wait_for_timeout(1300)
    m = await pg.evaluate("(()=>{ const e=document.getElementById('abcFsMenu'); if(!e) return null; const r=e.getBoundingClientRect(); return {vis:getComputedStyle(e).display!=='none', txt:e.textContent, r:[r.right,r.bottom]}; })()")
    ok(f'menu: Full screen button bottom right ({m})', bool(m) and m['vis'] and 'Full screen' in m['txt'] and m['r'][0] > 1200 and m['r'][1] > 680)
    await battle(pg)
    ok('menu button hidden during play', await pg.evaluate("getComputedStyle(document.getElementById('abcFsMenu')).display==='none'"))
    g = await pg.evaluate("""(()=>{ const row=document.querySelector('#game .tb-btns'), f=row.querySelector('.abc-fsbtn'), tune=row.querySelector('[data-do=settings]'), menu=row.querySelector('[data-do=title]'), log=document.querySelector('.logtoggle');
      const R=e=>e.getBoundingClientRect(); return {last:row.lastElementChild===f, icon:f.textContent, left:R(f).right<=R(tune).left+0.5, gap:R(tune).left-R(f).right, noOverlap:R(menu).right<=R(log).left+0.5, h:Math.round(R(f).height)}; })()""")
    ok(f'board: icon sits left of Tune, row keeps its place, Menu clear of Log ({g})', g['last'] and g['icon'] == '⛶' and g['left'] and 3 <= g['gap'] <= 9 and g['noOverlap'] and g['h'] >= 30)
    await pg.evaluate("ABC_DEBUG.render(); ABC_DEBUG.render()")
    ok('board: icon survives re-renders (exactly one)', await pg.evaluate("document.querySelectorAll('#game .tb-btns .abc-fsbtn').length===1"))
    await pg.click('.tb-btns [data-do="settings"]'); await pg.wait_for_timeout(300)
    ok('Tune still opens Tune (not full screen)', await pg.evaluate("!document.fullscreenElement && !!document.querySelector('input[data-abcautoflat]')"))
    ok('Tune has "Auto flat board when slow" (on by default)', await pg.evaluate("document.querySelector('input[data-abcautoflat]').checked"))
    await pg.keyboard.press('Escape'); await pg.evaluate("ABC_DEBUG.APP.screen='play'; ABC_DEBUG.S._settings=false; ABC_DEBUG.render()"); await pg.wait_for_timeout(200)
    await pg.evaluate("document.querySelectorAll('.modal-bg').forEach(e=>e.remove())")
    await pg.click('#game .tb-btns .abc-fsbtn'); await pg.wait_for_timeout(500)
    f = await pg.evaluate("[!!document.fullscreenElement, document.body.classList.contains('abc-fs'), getComputedStyle(document.getElementById('abcFsExit')).display, document.querySelector('#game .tb-btns .abc-fsbtn').textContent]")
    ok(f'entering full screen: pill shows, icon flips ({f})', f[0] and f[1] and f[2] == 'flex' and f[3] == '⤡')
    pr = await pg.evaluate("(()=>{ const r=document.getElementById('abcFsExit').getBoundingClientRect(); return [Math.round(r.left+r.width/2), Math.round(r.top)]; })()")
    ok(f'pill is top centre ({pr})', abs(pr[0] - 640) <= 2 and pr[1] <= 12)
    await pg.wait_for_timeout(2800)
    ok('pill fades when the mouse rests', await pg.evaluate("document.body.classList.contains('abc-fs-idle') && parseFloat(getComputedStyle(document.getElementById('abcFsExit')).opacity)<0.5"))
    await pg.mouse.move(400, 300); await pg.wait_for_timeout(100)
    ok('pill returns on mouse move', await pg.evaluate("!document.body.classList.contains('abc-fs-idle')"))
    await pg.click('#abcFsExit'); await pg.wait_for_timeout(500)
    ok('pill exits full screen', await pg.evaluate("!document.fullscreenElement && !document.body.classList.contains('abc-fs') && document.querySelector('#game .tb-btns .abc-fsbtn').textContent==='⛶'"))
    # pre-loading
    pre = await pg.evaluate("""(()=>{ const S=ABC_DEBUG.S, u=new Set(); [S.you,S.opp].forEach(P=>P.team.forEach(c=>{ if(c.img&&c.img.length>30) u.add(c.img); }));
      const rs=document.documentElement.style; for(let i=0;i<rs.length;i++) if(rs[i].indexOf('--pf-')===0) u.add(rs[i]);
      return [ABC_FSX.pre.done, ABC_FSX.pre.q.length, !!ABC_FSX.pre.key, u.size]; })()""")
    ok(f'image pre-loading decoded both teams + frames at match start (done, queued, key, unique) {pre}', pre[0] >= pre[3] and pre[3] >= 5 and pre[1] == 0 and pre[2])
    # safety net
    ok('safety net idle on a smooth board', await pg.evaluate("document.body.classList.contains('abc-tilt') && !ABC_FSX.safe.flat"))
    await pg.evaluate(SLOW + "(3600)"); await pg.wait_for_timeout(300)
    s = await pg.evaluate("[ABC_FSX.safe.flat, document.body.classList.contains('abc-tilt'), document.getElementById('abcSafeNote')?.className, (document.getElementById('abcSafeNote')||{}).textContent, ABC_FSX.safe.log.length]")
    ok(f'3 s of slow frames switches to flat view with a note ({s})', s[0] and not s[1] and s[2] == 'show' and 'flat view' in (s[3] or '') and s[4] == 1)
    ok('flat view sticks through re-renders', await pg.evaluate("ABC_DEBUG.render(); !document.body.classList.contains('abc-tilt')"))
    ok('safety-net event records a snapshot', await pg.evaluate("(()=>{ const e=ABC_FSX.safe.log[0]; return !!e && e.slowMs>=1800 && e.snap && e.snap.view==='play' && e.snap.tilt===true; })()"))
    ok('stored tilt setting is untouched', await pg.evaluate("localStorage.getItem('abc_tilt')!=='off'"))
    await pg.click('#abcSafeNote [data-safe="keep"]'); await pg.wait_for_timeout(200)
    k = await pg.evaluate("[document.body.classList.contains('abc-tilt'), ABC_FSX.safe.flat, ABC_FSX.safe.user, document.getElementById('abcSafeNote').className]")
    ok(f'"Keep 3D" restores tilt and stops the safety net for this visit ({k})', k[0] and not k[1] and k[2] and k[3] == '')
    await pg.evaluate(SLOW + "(3600)"); await pg.wait_for_timeout(200)
    ok('after Keep 3D, slow frames do not flip it again', await pg.evaluate("document.body.classList.contains('abc-tilt')"))
    # 30 fps cap (power saving) must not trigger
    await pg.reload(); await pg.wait_for_timeout(1200); await battle(pg)
    await pg.evaluate("""new Promise(res=>{ const t0=performance.now(); (function f(){ const a=performance.now(); while(performance.now()-a<30){} if(performance.now()-t0<3600) requestAnimationFrame(f); else res(); })(); })""")
    ok('a steady ~30 fps (power-saving cap) does not trigger it', await pg.evaluate("document.body.classList.contains('abc-tilt') && !ABC_FSX.safe.flat"))
    # leaving the match resets
    await pg.evaluate(SLOW + "(3600)"); await pg.wait_for_timeout(200)
    ok('fires on a fresh visit', await pg.evaluate("ABC_FSX.safe.flat"))
    await pg.evaluate("ABC_DEBUG.APP.screen='menu'; ABC_DEBUG.render()"); await pg.wait_for_timeout(1300)
    ok('leaving the match clears flat view (next match starts tilted)', await pg.evaluate("!ABC_FSX.safe.flat && document.getElementById('abcSafeNote').className===''"))
    ok('leaving the match drops pre-loaded images', await pg.evaluate("ABC_FSX.pre.keep.length===0 && !ABC_FSX.pre.key"))
    # Tune switch off
    await pg.evaluate("localStorage.setItem('abc_autoflat','off')"); await pg.reload(); await pg.wait_for_timeout(1200); await battle(pg)
    await pg.evaluate(SLOW + "(3600)"); await pg.wait_for_timeout(200)
    ok('Tune switch off = never flips', await pg.evaluate("document.body.classList.contains('abc-tilt') && !ABC_FSX.safe.flat"))
    await pg.evaluate("localStorage.removeItem('abc_autoflat')")
    # meter v3
    await pg.evaluate("localStorage.setItem('abc_perfmeter','on')"); await pg.reload(); await pg.wait_for_timeout(1200); await battle(pg)
    await pg.evaluate("ABC_PD.state.api='none'")
    await pg.evaluate("""(()=>{ requestAnimationFrame(()=>{ const t=performance.now(); while(performance.now()-t<120){} }); })()"""); await pg.wait_for_timeout(600)
    r = await pg.evaluate("(()=>{ const s=ABC_PD.report(); const j=JSON.parse(s.slice(s.indexOf('\\n')+1)); return {v:j.meter, snaps:j.slowSnapshots.length, s0:j.slowSnapshots[0]||null, af:!!j.autoFlat, fs:j.fullscreen, now:!!j.now}; })()")
    ok(f'meter v3 report: slow-frame snapshots, auto-flat + full-screen state ({ {k:v for k,v in r.items() if k!="s0"} })', r['v'] == 'v3' and r['snaps'] >= 1 and r['af'] and r['fs']['mode'] == 'fullscreen' and r['now']
       and all(k in r['s0'] for k in ('phase', 'inspect', 'hand', 'anims', 'dom', 'hover', 'frameMs')))
    await pg.evaluate("localStorage.removeItem('abc_perfmeter')")
    ok('desktop: no page errors', not errs)
    await ctx.close()
    # ---------- embed without full-screen permission ----------
    ctx = await b.new_context(viewport={'width': 1100, 'height': 760}); pg = await ctx.new_page(); errs2 = []
    host = STUB_PATH.parent / '_fs_host.html'
    host.write_text('<!doctype html><body style="margin:0"><iframe allow="fullscreen \'none\'" src="' + STUB_PATH.name + '" style="width:1000px;height:700px;border:0"></iframe></body>')
    await pg.goto(host.as_uri()); await pg.wait_for_timeout(1500)
    fr = pg.frames[1]; fr.page.on('pageerror', lambda e: errs2.append(str(e)))
    e = await fr.evaluate("[ABC_FSX.mode(), (document.getElementById('abcFsMenu')||{}).textContent]")
    ok(f'embed that blocks full screen: button offers a new window ({e})', e[0] == 'window' and 'Open full window' in (e[1] or ''))
    host.unlink()
    await ctx.close()
    # ---------- phone ----------
    ctx = await b.new_context(viewport={'width': 390, 'height': 844}, has_touch=True, is_mobile=True); pg = await ctx.new_page(); errs3 = []; pg.on('pageerror', lambda e: errs3.append(str(e)))
    await pg.goto(STUB_URL); await pg.wait_for_timeout(1200); await battle(pg)
    ph = await pg.evaluate("""(()=>{ const f=document.querySelector('#game .tb-btns .abc-fsbtn'); if(!f) return 'none'; const r=f.getBoundingClientRect(), t=document.querySelector('#game .tb-btns [data-do=settings]').getBoundingClientRect(), nm=document.querySelector('.side-meta, .opp-name, .tb-l')?.getBoundingClientRect();
      return {left:r.left, clear:r.right<=t.left+0.5, sw:document.documentElement.scrollWidth}; })()""")
    ok(f'phone: icon fits left of Tune, no sideways scroll ({ph})', ph == 'none' or (ph['left'] >= 0 and ph['clear'] and ph['sw'] <= 390))
    ok('phone: no tilt, safety net stays idle', await pg.evaluate("!document.body.classList.contains('abc-tilt') && !ABC_FSX.safe.flat"))
    ok('phone/embed: no page errors', not errs3 and not errs2)
    await ctx.close()
    print('\n'.join(res)); print(sum(r.startswith('PASS') for r in res), '/', len(res)); globals()['_FAILS'] = sum(r.startswith('FAIL') for r in res); await b.close()
asyncio.run(main())
import sys; sys.exit(1 if globals().get('_FAILS') else 0)
