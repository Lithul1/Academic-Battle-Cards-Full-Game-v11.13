# ABC — fix_fullscreen_smooth handoff (2026-11-03)

**Why:** a series of Safari lab tests (`make_lab.py`) could not reproduce the in-play Safari lag.
- Every tilt mode was smooth: 165 fps at 1439×960 and at 1920×1080.
- But in Trevor's real session, turning tilt off took Safari from 25 to 161 fps.
- **Decision:** ship full screen, image pre-loading, and an automatic flat-board fallback, plus better diagnostics to catch the trigger next time.

**Needs:** fix_safari_perf.py. **Install:** `python3 fix_fullscreen_smooth.py && python3 build.py`.

## Changes
- **CSS:** before `</style>\n</head>`.
- **JS:** a block before `function menuScreen(){`.
- **Tune:** a new row "Auto flat board when slow" (`data-abcautoflat`, localStorage `abc_autoflat`), plus its handler line.

1. **Full screen**
   - **Buttons:**
     - Board: a `.abc-fsbtn` appended *last* in `.tb-btns`, so morph keeps Tune/Menu matched. It is positioned absolutely, just left of the row.
     - Menu: `#abcFsMenu`, fixed bottom right, styled like the gold buttons, shown only while `data-screen=menu`.
   - **Exit:** `#abcFsExit` pill at top centre while in full screen. It fades (`abc-fs-idle`) after 2.5s without input. Esc also exits.
   - **Events:** clicks are handled by a delegated capture listener (no `onclick` on nodes morph reuses). `fullscreenchange` (+ webkit) → `abcFsSync`, which updates the labels and fires `resize` so `fitBoard` rescales.
   - **Modes** (`abcFsMode()`):
     - `fullscreen`: the API is available.
     - `window`: in an iframe that blocks it; the button opens a new tab.
     - `none`: e.g. iPhone; no buttons.
   - **Hooks:** `render` is wrapped, plus a 1s interval fallback, to re-add the board icon after re-renders.
2. **Image pre-loading** (`ABC_PRE`, `abcPreAfter`, `abcPrePump`)
   - When a match's teams change, both teams' `c.img` plus the `--pf-*` print frames are decoded one at a time (`Image.decode()`, 40ms gaps).
   - References are kept until the player leaves play.
   - Targets the 0.5–0.7s freezes; that cause is a hypothesis.
3. **Auto flat board** (`ABC_SAFE`, `abcSafeLoop`)
   - **What it watches:** in play, with tilt on, while the page is visible. If frames over 50ms add up to ≥1800ms of the last 3s, it fires once.
     - A steady 30 fps power-saving cap never triggers it.
   - **When it fires:**
     - `flat=true`; `abcTiltOn` is wrapped to return false, so render keeps tilt off.
     - Fit and turn bar are recalculated.
     - A note appears at top centre for 9s with "Keep 3D" and ✕.
   - **Keep 3D:** goes through `abcTiltSet(true)`, which is wrapped. It clears flat and sets `user=true`, which stops the safety net until reload.
   - **Next match:** leaving play clears flat.
   - The stored `abc_tilt` setting is never changed.
4. **Meter v3**
   - `abcPdTick` is wrapped: a snapshot is taken at most once per second on slow frames while the meter is on.
   - `abcPdReport` is wrapped; the report gains:
     - `meter:'v3'`
     - `now`
     - `slowSnapshots[]`: phase, turn, hand/bench/char counts, flying cards, effects, modal, Inspect state, last hover class, DOM size, animations by name, tilt, autoFlat, full screen, window
     - `autoFlat{active, keep3d, events[]}`: each event carries a snapshot
     - `fullscreen{mode, on}`
     - `preload{done, queued}`

Debug export: `window.ABC_FSX = {fs, toggle, mode, pre, safe, fire, snap, after}`.

## Tests
- New: `test_fullscreen_smooth.py` (30 checks) covers:
  - desktop full screen enter, idle fade and exit
  - Tune unaffected
  - pre-loading
  - the safety net: fires, sticks through renders, Keep 3D, the 30 fps cap, reset after leaving, the Tune switch
  - the meter v3 report
  - an embed with `allow="fullscreen 'none'"` → "Open full window"
  - phone fit
- Full suite: 22/22 suites, plus both validators.

## Next
- When Safari lag happens again, Trevor copies the meter report; `slowSnapshots`/`autoFlat.events` should name the trigger.
- Still open: whether the 0.5–0.7s freezes are image decoding.
