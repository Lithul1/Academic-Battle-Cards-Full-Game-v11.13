# Handoff: book menu (fix_menu_book.py)

This is Concept A from the menu preview, as approved, with two additions borrowed from the other concepts:
- the ACT tabs as section headings
- the dealt-card entrance for the two featured buttons

It needs no other patch. If fix_challenges is applied, the menu also shows the challenge streak and the claim badge.

## What it does
- **Left page:**
  - The crest and the title.
  - Two featured buttons. On a first visit: **Start here: Watch the Tutorial**, then Quickplay. Afterwards: **Continue reading: <last mode>**, then Quickplay. If the last mode was Quickplay, the second slot is Literary Scrimmage instead.
  - A daily-challenge strip: streak, today's x/3 done, and rewards to claim. Tapping it opens Challenges.
- **Right page:** the table of contents.
  - Three sections: ACT I Play, ACT II Campaign, ACT III Study. The ACT tab colours match the printed card frames.
  - Roman numerals, dotted leaders, and page numbers (the numbers are decorative).
  - Hover draws an ink underline and shows a one-line description. On phone the descriptions are always shown.
- **Ribbon:** marks your last chapter, or the Tutorial on a first visit.
  - The last mode is stored in `localStorage abc_lastmode`.
  - It's set by Quickplay, Custom Play, Pagemaster, PreCon Arena and Literary Scrimmage only.
- **Choosing a chapter:**
  - Plays `SFX.card('book_flip')` and turns the page over 0.55s.
  - The original click runs again at 0.3s, while the page is mid-turn.
  - With Calm effects or the system reduced-motion setting, there's no animation and the action runs at once.
- **Background:** the menu sits on the board's dark table. Sub-screens keep their current art.
- **Phone:** the two pages stack into one.
- **Unchanged:** every button keeps its existing `data-do`, so no handler changed. No assets are added.

## Hooks
- 1 early return in `menuScreen()`. The old menu stays underneath as the fallback.
- The JS block goes before `menuScreen`, plus the CSS.
- A capture-phase click listener on `.mb [data-do]` handles remembering the last mode, the sound and the page turn.

## Tests
- `test_menu_book.py`: 36 checks across desktop and phone. They cover:
  - all 10 actions present
  - the featured logic
  - ribbon placement
  - page turn, then the action runs once
  - Calm effects runs the action immediately
  - no horizontal scroll
  - the dark table background

## Follow-ups
- **Playable tutorial:** when it exists, point the first-visit button at it instead of the video.
- **Sub-screens:** difficulty, custom, Arena setup and Scrimmage could get the same paper and typography in a second, smaller patch.

## Update: fix_menu_book2.py (run after fix_menu_book.py)

The patch replaces the menu JS and CSS block that v1 added. It checks for an exact match first, so it refuses to run if that block was edited.

- **Speed:**
  - Removed the drop-shadow filter on the whole book. It re-rasterised the full spread on every hover. The pages now use a plain shadow and `contain: layout paint`.
  - Hovering no longer grows the row, which used to re-lay out the page. The row's description now appears in a caption at the foot of the contents page.
  - The ribbon moves with a transform instead of changing height.
  - Measured with CPU slowed 6x: median hover frame dropped from 50ms to 17ms, and frames over 50ms from 37 to 3. Click to the next screen dropped from 477ms to 65ms.
- **Fit:** the book is laid out at 1020px wide and zoomed to fill 94% of the window's width or height, whichever is smaller (0.62x to 1.3x), and it's centred vertically. CSS `zoom` re-lays out the text, so it stays sharp. The phone layout is unchanged.
- **Page turn:** the turning sheet is the exact position and size of the contents page (clamped to the viewport on phone). It lasts 0.45s, and the next screen is built underneath it straight away.
- **Tests:** `test_menu_book.py` now has 44 checks. New ones cover:
  - no filter on the book
  - row heights stay the same on hover, and the caption shows
  - the book fits and fills the window
  - the sheet matches the page
  - the next screen is already underneath while the page turns
