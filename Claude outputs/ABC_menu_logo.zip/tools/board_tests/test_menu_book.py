import asyncio
import os, pathlib
_ROOT = pathlib.Path(__file__).resolve().parents[2]
STUB_URL = (pathlib.Path(os.environ.get('ABC_STUB', _ROOT / 'dist' / 'stub.html')).resolve()).as_uri()
_CHROME = os.environ.get('ABC_CHROME')
def _launch_kw(): return {'executable_path': _CHROME} if _CHROME else {}
from playwright.async_api import async_playwright
ACTS = ['go-quick', 'go-custom', 'go-pagemaster', 'go-arena', 'go-scrim', 'go-challenges', 'builder', 'go-index', 'go-guide', 'go-tutorial']

async def main():
  async with async_playwright() as p:
    b = await p.chromium.launch(**_launch_kw())
    res = []; ok = lambda n, c: res.append(('PASS' if c else 'FAIL') + '  ' + n)
    for vw, vh, touch, t in [(1280, 800, False, 'desk'), (390, 844, True, 'phone')]:
      ctx = await b.new_context(viewport={'width': vw, 'height': vh}, has_touch=touch, is_mobile=touch); pg = await ctx.new_page()
      errs = []; pg.on('pageerror', lambda e: errs.append(str(e)))
      await pg.goto(STUB_URL); await pg.wait_for_timeout(900)
      await pg.evaluate("localStorage.removeItem('abc_lastmode'); ABC_DEBUG.render()"); await pg.wait_for_timeout(800)
      ok(f'{t} menu is the open book', await pg.evaluate("!!document.querySelector('#game .mb-book .mb-page.l') && !!document.querySelector('#game .mb-page.r .mb-toc')"))
      rows = await pg.evaluate("[...document.querySelectorAll('.mb-toc [data-do]')].map(e=>e.dataset.do)")
      ok(f'{t} contents has all 10 modes with their original actions', sorted(rows) == sorted(ACTS))
      ok(f'{t} three acts in the contents', await pg.evaluate("[...document.querySelectorAll('.mb-part')].map(e=>e.textContent.replace(/\\s+/g,'')).join('|')") == 'ACTIPlay|ACTIICampaign|ACTIIIStudy')
      ok(f'{t} crest kept on the title page', await pg.evaluate("!!document.querySelector('.mb-page.l .mb-crest')"))
      f = await pg.evaluate("[...document.querySelectorAll('.mb-feat')].map(e=>e.dataset.do)")
      ok(f'{t} first visit: Tutorial is featured, then Quickplay ({f})', f == ['go-tutorial', 'go-quick'])
      if not touch:
        rib = await pg.evaluate("(()=>{ const b=document.querySelector('.mb-book').getBoundingClientRect(), r=document.querySelector('.mb-ribbon').getBoundingClientRect(), row=document.querySelector('.mb-toc [data-do=\"go-tutorial\"]').getBoundingClientRect(); return Math.abs(r.bottom-(row.top+row.height/2+8)); })()")
        ok(f'desk ribbon marks the Tutorial on a first visit (off {rib:.0f}px)', rib < 14)
      await pg.evaluate("localStorage.setItem('abc_lastmode','go-arena'); ABC_DEBUG.render()"); await pg.wait_for_timeout(600)
      f = await pg.evaluate("[...document.querySelectorAll('.mb-feat')].map(e=>[e.dataset.do, e.querySelector('small').textContent])")
      ok(f'{t} returning: Continue reading = last mode', f[0] == ['go-arena', 'Continue reading'] and f[1][0] == 'go-quick')
      if not touch:
        rib = await pg.evaluate("(()=>{ const r=document.querySelector('.mb-ribbon').getBoundingClientRect(), row=document.querySelector('.mb-toc [data-do=\"go-arena\"]').getBoundingClientRect(); return Math.abs(r.bottom-(row.top+row.height/2+8)); })()")
        ok(f'desk ribbon moves to the last chapter (off {rib:.0f}px)', rib < 14)
      await pg.evaluate("localStorage.setItem('abc_lastmode','go-quick'); ABC_DEBUG.render()"); await pg.wait_for_timeout(300)
      ok(f'{t} last mode Quickplay: second slot offers the Scrimmage', await pg.evaluate("[...document.querySelectorAll('.mb-feat')].map(e=>e.dataset.do).join()") == 'go-quick,go-scrim')
      ok(f'{t} challenge strip links to Challenges', await pg.evaluate("document.querySelector('.mb-daily').dataset.do==='go-challenges'"))
      ok(f'{t} no drop-shadow filter on the book (hover stays cheap)', await pg.evaluate("getComputedStyle(document.querySelector('.mb-book')).filter")=='none')
      h0 = await pg.evaluate("[...document.querySelectorAll('.mb-row')].map(e=>e.offsetHeight).join()")
      if not touch:
        await pg.hover('.mb-row[data-do="go-pagemaster"]'); await pg.wait_for_timeout(350)
        ok('desk hover does not resize rows; caption shows the description', await pg.evaluate("[...document.querySelectorAll('.mb-row')].map(e=>e.offsetHeight).join()")==h0 and await pg.evaluate("document.querySelector('.mb-cap').textContent")=='Two commanders, one or two books.')
        fit = await pg.evaluate("(()=>{ const r=document.querySelector('.mb-book').getBoundingClientRect(); return [r.left>=0, r.right<=innerWidth, r.top>=0, r.bottom<=innerHeight+12, r.width/innerWidth]; })()")
        ok(f'desk book fits the window and fills it ({fit[4]:.2f} of the width)', all(fit[:4]) and fit[4] > .6)
      ok(f'{t} no horizontal scroll', await pg.evaluate("document.documentElement.scrollWidth<=innerWidth"))
      ok(f'{t} menu sits on the dark table', await pg.evaluate("getComputedStyle(document.body,'::before').backgroundColor") == 'rgb(43, 38, 32)')
      # selecting: page turn, flip sound, the original action runs, last mode recorded
      await pg.evaluate("window.__snd=[]; const o=ABC_DEBUG.SFX.card; ABC_DEBUG.SFX.card=function(k,v){ __snd.push(k); try{ return o.apply(this,arguments); }catch(e){} }")
      sel = '.mb-toc [data-do="go-custom"]'
      await pg.locator(sel).scroll_into_view_if_needed(); await pg.wait_for_timeout(100)   # measure where the page is when it is tapped
      pr = await pg.evaluate("(()=>{ const r=document.querySelector('.mb-page.r').getBoundingClientRect(); return [r.left,Math.max(r.top,0),r.width,Math.min(r.bottom,innerHeight)-Math.max(r.top,0)].map(Math.round); })()")
      if touch: await pg.tap(sel)
      else: await pg.click(sel)
      await pg.wait_for_timeout(60)
      sh = await pg.evaluate("(()=>{ const i=document.querySelector('.mb-turn i'); return i?[i.style.left,i.style.top,i.style.width,i.style.height].map(v=>Math.round(parseFloat(v))):null; })()")
      ok(f'{t} turning sheet is exactly the contents page ({sh} vs {pr})', bool(sh) and all(abs(a-b)<=2 for a,b in zip(sh,pr)))
      ok(f'{t} choosing turns the page', await pg.evaluate("!!document.querySelector('.mb-turn.go')"))
      ok(f'{t} the next screen is already underneath the turning page', await pg.evaluate("ABC_DEBUG.APP.screen")=='difficulty')
      await pg.wait_for_timeout(700)
      st = await pg.evaluate("[ABC_DEBUG.APP.screen, localStorage.getItem('abc_lastmode'), !!document.querySelector('.mb-turn'), __snd.filter(k=>k==='book_flip').length]")
      ok(f'{t} then runs the original action, once ({st})', st[0] == 'difficulty' and st[2] is False and st[3] == 1)
      ok(f'{t} records the last mode', st[1] == 'go-custom')
      await pg.evaluate("document.querySelector('[data-do=menu]').click()"); await pg.wait_for_timeout(300)
      ok(f'{t} back to the menu shows the book again', await pg.evaluate("!!document.querySelector('.mb-book')"))
      # calm: no page turn, immediate
      await pg.evaluate("document.body.classList.add('calm-fx')")
      await pg.evaluate("document.querySelector('.mb-toc [data-do=\"go-guide\"]').click()"); await pg.wait_for_timeout(60)
      ok(f'{t} Calm effects: no page turn, action runs at once', await pg.evaluate("ABC_DEBUG.APP.screen==='guide' && !document.querySelector('.mb-turn')"))
      ok(f'{t} the Tutorial does not count as a last mode', await pg.evaluate("localStorage.getItem('abc_lastmode')") == 'go-custom')
      await pg.evaluate("document.body.classList.remove('calm-fx'); ABC_DEBUG.APP.screen='menu'; ABC_DEBUG.render()")
      ok(f'{t} no page errors', not errs)
      await ctx.close()
    print('\n'.join(res)); print(sum(r.startswith('PASS') for r in res), '/', len(res)); globals()['_FAILS'] = sum(r.startswith('FAIL') for r in res); await b.close()
asyncio.run(main())
import sys; sys.exit(1 if globals().get('_FAILS') else 0)
