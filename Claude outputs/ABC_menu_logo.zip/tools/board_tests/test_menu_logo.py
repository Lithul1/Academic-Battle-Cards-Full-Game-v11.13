import asyncio, os, pathlib
_ROOT = pathlib.Path(__file__).resolve().parents[2]
URL = (pathlib.Path(os.environ.get('ABC_STUB', _ROOT / 'dist' / 'stub.html')).resolve()).as_uri()
_CHROME = os.environ.get('ABC_CHROME')
def _launch_kw(): return {'executable_path': _CHROME} if _CHROME else {}
SHOT=os.environ.get('LOGO_SHOTS')
from playwright.async_api import async_playwright
R=[]; ok=lambda n,c: R.append(('PASS' if c else 'FAIL')+'  '+n)
async def main():
  async with async_playwright() as p:
    b=await p.chromium.launch(**_launch_kw())
    for w,h,touch,tag in [(1280,800,False,'desk'),(390,844,True,'phone')]:
      pg=await b.new_page(viewport={'width':w,'height':h},has_touch=touch,is_mobile=touch); errs=[]; pg.on('pageerror',lambda e: errs.append(str(e)))
      await pg.goto(URL); await pg.wait_for_timeout(1500)
      r=await pg.evaluate("""(()=>{ const c=document.querySelector('.mb-crest'), r=c.getBoundingClientRect(), cs=getComputedStyle(c);
        const vis=e=>e && getComputedStyle(e).display!=='none';
        return {logo:window.ABC_LOGO===window.ABC_CREST, src:c.src===window.ABC_CREST, nat:[c.naturalWidth,c.naturalHeight], w:Math.round(r.width), shadow:cs.boxShadow,
          t1:vis(document.querySelector('.mb-wm .t1')), t2:vis(document.querySelector('.mb-wm .t2')), t3:vis(document.querySelector('.mb-wm .t3')), sw:document.documentElement.scrollWidth}; })()""")
      ok(f'{tag} menu shows the new logo (640×714), no frame, tagline only ({r})', r['logo'] and r['nat']==[640,714] and r['shadow']=='none' and not r['t1'] and not r['t2'] and r['t3'] and r['sw']<=w and 200<=r['w']<=300)
      if SHOT: await pg.screenshot(path=f'{SHOT}_{tag}_menu.png')
      # every other place the old small logo appeared now shows the same art, unframed
      for scr,setup in [('difficulty',"A.mode='custom'"),('custom',"A.mode='custom'"),('pmpick',"A.mode='pagemaster'; A.drawnMode=true; A.pmCommanders=[]")]:
        await pg.evaluate(f"(()=>{{ const A=ABC_DEBUG.APP; {setup}; A.screen='{scr}'; ABC_DEBUG.render(); }})()"); await pg.wait_for_timeout(150)
        q=await pg.evaluate("[...document.querySelectorAll('#game img.title-logo')].map(i=>[i.src===window.ABC_LOGO, getComputedStyle(i).boxShadow])")
        ok(f'{tag} {scr}: small logo uses the new art without a frame ({q})', len(q)>0 and all(x[0] and x[1]=='none' for x in q))
      await pg.evaluate("(()=>{ const A=ABC_DEBUG.APP; A.screen='menu'; ABC_DEBUG.render(); })()"); await pg.wait_for_timeout(200)
      ok(f'{tag} no page errors', not errs); await pg.close()
    print('\n'.join(R)); print(sum(r.startswith('PASS') for r in R),'/',len(R)); globals()['_FAILS']=sum(r.startswith('FAIL') for r in R); await b.close()
asyncio.run(main())
import sys; sys.exit(1 if globals().get('_FAILS') else 0)
