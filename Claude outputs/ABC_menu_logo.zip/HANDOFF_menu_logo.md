# ABC — fix_menu_logo handoff (2026-11-05)

**Why:** Trevor supplied a new logo PNG (the title above the red and blue book characters on newsprint) for the menu. It should blend with the menu page.
**Approved in preview** (`make_logo_preview.py`), version A. Trevor's calls:
- Remove the old crest.
- Use the new art everywhere the logo or crest appeared.

**Install:** `python3 fix_menu_logo.py && python3 build.py`.
**Writes:** `src/game.src.html` and `assets/assets.json`; both get a `.bak_<stamp>`.
**Needs:** fix_menu_book.

## Asset
- Made once from the PNG; no runtime blending, no filters or blend modes.
- **Padding:** 28px of page-coloured margin so the letters never touch the edge.
- **Foreground:** saturated colour (title, books, shield), dilated and blurred to take in outlines, gloves and faces. It stays fully opaque.
- **Halo and paper:** the halo fades out in a narrow band at the edges, and the paper/newsprint feathers out over the outer ~20%.
- **Colour:** the paper is scaled to the menu page colour (`--mb-paper #f6eedb`).
- **Output:** 640×714 WebP q82, about 91 KB, in a fresh asset slot (a1163 in the test bundle; the patch picks max+1).

## Changes
- `window.ABC_CREST` and `window.ABC_LOGO` both point at the new asset.
- The old a110 (crest) and a107 (logo) are removed from assets.json, after checking nothing references them.
- **Menu title page:**
  - The crest is `width:min(300px,88%)` (250px on phones), with its space reserved by `aspect-ratio:640/714`.
  - The wordmark's "ACADEMIC" and "Battle Cards" lines are hidden (the logo carries the title); the "A LITERARY SCRIMMAGE" tagline stays.
- **`.title-logo` (the small logo):** no rounded frame or shadow, `aspect-ratio` reserved. It's still hidden on the book-style sub-pages, as before.
- vcheck reports two expected differences: "asset placeholders identical: false" and "original lines missing: 2" (the two logo lines).

## Tests
- New: `test_menu_logo.py` (10 checks). On desktop and phone it checks that the menu shows the new 640×714 art with no frame and the tagline only, with no sideways scroll; and that the difficulty, custom and Pagemaster screens' small logo uses the new art without a frame.
- Changed: `test_menu_book.py` now scrolls the Contents entry into view before measuring the page-turn sheet. The taller logo pushes it below the fold on phones, and Playwright's tap used to scroll after the measurement.
- Full suite: 27/27 suites (the menu-book suite after this update). validate.js: 8/8.
