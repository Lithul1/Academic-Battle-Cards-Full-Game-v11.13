# ABC — fix_dragdrop_cards handoff (2026-11-03)

**Why:** Trevor wanted drag-and-drop placement so play feels strategic, plus a hand-card view reworked from his mockup: icon buttons beside the card, lens text on the card. Three preview rounds (`make_dd_preview*.py`) were approved.

**Needs:** fix_print_cards.py (`abcPcLensFace`) and fix_gameplay_perf.py (`abcMorph`). Chain-tested after fix_fullscreen_smooth.
**Install:** `python3 fix_dragdrop_cards.py && python3 build.py`.

## Changes (CSS before `</style>\n</head>`, JS before `function menuScreen(){`)

### A. Hand-card view (`handViewModal` reassigned)
- **Buttons:** labelled icon buttons `.hv2-b`: Play (gold), Discard (with a badge showing discards left), Close.
  - They sit in a column beside the card.
  - On **ABC attack/block cards** they sit in a row underneath, because those cards are wide and short.
  - The `data-do` values are unchanged (`playhand` / `dischand` / `closehand`).
- **Info panels:** these sit in `.hv2-col` under the card, at exactly the card's width.
  - Lenses don't get the panels: their text is on the card.
  - Framed bookmarks (`pfb`) don't either: the card already prints the effect.
- **Lens card:** uses the `full` lens face with `abcPcLensPanels`.
  - `abcHvFit()` runs after each render. Text stays on the plates while it fits at ≥3.3cqw (about 13px at 400px wide); otherwise the card gets `.hv2-stack`.
  - `.hv2-stack` crops the art and shows full-text panels below at 14px.
  - These seven lenses currently stack: Postcolonial, Formalism, Deconstruction, Structuralism, Affective Fallacy, Mise En Scène, Adaptation.
  - Phone cards are narrower than 300px, so the existing container query stacks them (bumped to 13px).
- **Sizing:** the card sizes to the window height, which fixes Play/Discard falling below the screen on short windows.
- **Naming:** kind classes are `hv2-k-*`. Plain `hv2-lens` collided with the card class.

### B. Drag-and-drop (window capture-phase pointer handlers; the old ABC-only drag is blocked by `stopPropagation`)

| Card | Drop zones | Action |
|---|---|---|
| ABC charge | your Active + Backstage minis (label `⚔ Name have→have+1/need`) | `tryPlayHandCard(idx, uid)` |
| Character (drawn modes) | "Place … as your Active" (your board area above the Backstage strip, when there's no live Active) / "Send … Backstage" (Backstage strip) | `drawnPlace(idx,'active'/'bench')` in the opening placement, else `tryPlayHandCard` |
| Critical Lens | your lens chip | `tryPlayHandCard` |
| Held bookmark, Active-only (Highlight, Laminate, Hardcover, Margin Notes, Iron Curtain, Antiquarian, Plot Armor) | your Active | `tryPlayHandCard` |
| Held bookmark, side-wide (Supercharge, Truce, Cliffnotes, Dog-ear, Extra Credit, Saga, Censorship, Cliffhanger) | your Active (+ `.abm-zone` if present) | `tryPlayHandCard` |
| Target bookmarks: own (Horizon's Promise, Heal, Porch Stories, Muck Survival) / own Backstage (Gekokujō, F77 boost/guard, Trading) / enemy Backstage (F77 rip/burn) | the matching characters | `pickUid` is set; the `askPick` wrapper answers the question (matched by uid, or by team index for Trading) |

- **Ghost:** a clone of the hand card. It's positioned before it is shown and follows the pointer by transform, with no transition while dragging.
  - Drop on a zone: it flies into the zone (0.17s). Drop elsewhere: it slides back (0.2s).
- **Zones:** each gets a fixed-position `.dd-ring` overlay and a `.dd-chip` label.
  - Backstage minis show a short chip; the zone under the pointer shows the full label.
  - `abcDdZoneAt` uses `elementsFromPoint`, skipping the ghost, then falls back to region rectangles (`.row` is `display:contents` in the arena layout).
- **Taps:** buttons inside a card (ⓘ, ★ Active, ▼ Bench) never start a drag. The click that ends a drag is swallowed. Esc cancels.
- **Mid-drag renders:** `render` is wrapped to re-mark zones and to run `abcHvFit`.

Debug export: `window.ABC_DDX = {dd, kind, begin, end, targets, fit, zoneAt}`.

## Tests
- New: `test_dragdrop_cards.py` (20 checks). It covers:
  - lens readability and stacking
  - button labels and layouts
  - the ghost's start position and that it has no transition
  - every drop type: ABC, lens, held bookmarks, Heal on a Backstage ally, enemy-reserve bookmark, outside drop, character to Active then Backstage
  - phone fit
- Full suite: 23/23 suites, plus both validators. test_cardplay's "discarded card lands on the discard pile" can miss once under full-suite load (an animation-timing sample), like the known test_phone names flake. It passes standalone.

## Notes
- `ABC_DEBUG.render` is the unwrapped render, so in tests call `ABC_DDX.fit()` after it.
- Preview lesson: a re-downloaded file gets saved as "name (1).py", so ship new preview builders under new names.
