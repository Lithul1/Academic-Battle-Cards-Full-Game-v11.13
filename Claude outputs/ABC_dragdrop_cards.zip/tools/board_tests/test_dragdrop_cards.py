import asyncio, os, pathlib, sys
_ROOT = pathlib.Path(__file__).resolve().parents[2]
URL = (pathlib.Path(os.environ.get('ABC_STUB', _ROOT / 'dist' / 'stub.html')).resolve()).as_uri()
_CHROME = os.environ.get('ABC_CHROME')
def _launch_kw(): return {'executable_path': _CHROME} if _CHROME else {}
from playwright.async_api import async_playwright
CEN="(s=>{ const e=document.querySelector(s); if(!e) return null; const r=e.getBoundingClientRect(); if(e.matches('.hand .hc')) return [r.left+12, r.top+r.height*0.35]; return [r.left+r.width/2, r.top+r.height/2]; })"
GIVE="""(kind=>{ const D=ABC_DEBUG,S=D.S; D.freeze(); D.busy=false; S.turn='you'; S.phase='strategize'; S.you.crit=null; S.you.attachesLeft=2; S.you.flags.bmCount=0;
  let c; if(kind==='crit') { c=JSON.parse(JSON.stringify(DATA.crits.find(x=>/queer/i.test(x.name))||DATA.crits[0])); c.cat='crit'; }
  else if(kind.startsWith('bm:')){ const e=kind.slice(3); const f=DATA.bookmarks.find(b=>b.effect===e); c=f?JSON.parse(JSON.stringify(f)):{name:'Test '+e, effect:e, kind:'item'}; c.cat='bookmark'; }
  else c=S.you.hand.find(x=>x.cat==='abc');
  c._new=false; if(S.you.hand.indexOf(c)<0) S.you.hand.unshift(c); D.render(); return S.you.hand.indexOf(c); })"""
R=[]; ok=lambda n,c: R.append(('PASS' if c else 'FAIL')+'  '+n)
async def fresh(b, w=1280, h=800, drawn=False):
  pg=await b.new_page(viewport={'width':w,'height':h}); pg._e=[]; pg.on('pageerror',lambda e: pg._e.append(str(e)))
  await pg.goto(URL); await pg.wait_for_timeout(1000)
  await pg.evaluate("ABC_DEBUG.APP.drawnMode=%s; ABC_DEBUG.startBattle()" % ('true' if drawn else 'false')); await pg.wait_for_timeout(3000); return pg
async def drag(pg, sel_or_idx, target, up=True, kind=None):
  i=sel_or_idx if isinstance(sel_or_idx,int) else await pg.evaluate(GIVE, sel_or_idx); await pg.wait_for_timeout(120)
  a=await pg.evaluate("""(i=>{ const el=[...document.querySelectorAll('#game .hand .hc')].find(e=>e.dataset.idx==String(i) || e.querySelector('[data-do="dminfo:'+i+'"]')); if(!el) return null;
    const r=el.getBoundingClientRect();   /* a visible point of this card (the fanned hand overlaps neighbours) */
    for(const fy of [0.35,0.2,0.5,0.65,0.1]) for(const fx of [0.1,0.25,0.5,0.75,0.9]){ const x=r.left+r.width*fx, y=r.top+r.height*fy, h=document.elementFromPoint(x,y);
      if(h && h.closest('.hc')===el && !h.closest('button')) return [x,y]; }
    return [r.left+12, r.top+r.height*0.35]; })""", i); t=target if isinstance(target,tuple) else await pg.evaluate(CEN, target)
  await pg.mouse.move(*a); await pg.mouse.down(); await pg.mouse.move(a[0]+10,a[1]-10)
  first=await pg.evaluate("(()=>{ const g=document.querySelector('.dd-ghost'); if(!g) return null; const r=g.getBoundingClientRect(); return [r.left,r.top,getComputedStyle(g).transitionDuration]; })()")
  for k in range(1,9): await pg.mouse.move(a[0]+(t[0]-a[0])*k/8, a[1]+(t[1]-a[1])*k/8); await pg.wait_for_timeout(16)
  await pg.wait_for_timeout(60)
  info=await pg.evaluate("[document.querySelectorAll('.dd-ring').length, [...document.querySelectorAll('.dd-chip')].map(c=>c.textContent).join(' | '), !!document.querySelector('.dd-ring.hot')]")
  if up: await pg.mouse.up(); await pg.wait_for_timeout(450)
  return info, first, a
async def m():
  async with async_playwright() as p:
    b=await p.chromium.launch(**_launch_kw())
    # --- card view ---
    pg=await fresh(b)
    fits=await pg.evaluate("""(async()=>{ const D=ABC_DEBUG,S=D.S,out={}; D.freeze(); D.busy=false; S.turn='you'; S.phase='strategize'; for(const L of DATA.crits){ const c=JSON.parse(JSON.stringify(L)); c.cat='crit'; c._new=false; S.you.hand.unshift(c); S._handView=0; D.render(); ABC_DDX.fit(); await new Promise(r=>setTimeout(r,30));
       const el=document.querySelector('.hv2-lens'); const fs=[...el.querySelectorAll('.pfl-pan')].map(p=>parseFloat(getComputedStyle(p).fontSize)); out[L.name]=[el.classList.contains('hv2-stack'), Math.min(...fs)]; S._handView=null; S.you.hand.shift(); D.render(); } return out; })()""")
    st=[k for k,v in fits.items() if v[0]]; small=min(v[1] for v in fits.values())
    ok(f'every lens readable: smallest text {small:.1f}px; stacked layout for {st}', small >= 11.9 and 'Adaptation' in st)
    for k,shot in [('crit','v_lens'),('bm:highlight','v_bm'),('abc','v_abc')]:
      i=await pg.evaluate(GIVE,k); await pg.evaluate(f"ABC_DEBUG.S._handView={i}; ABC_DEBUG.render()"); await pg.wait_for_timeout(250); 
      lab=await pg.evaluate("[...document.querySelectorAll('.hv2-b .hv2-lbl')].map(e=>e.textContent+':'+(getComputedStyle(e).opacity==='1')).join(',')")
      lay=await pg.evaluate("(()=>{ const c=document.querySelector('.hv-card').getBoundingClientRect(), a=document.querySelector('.hv2-acts').getBoundingClientRect(); return a.top>=c.bottom-1?'below':(a.left>=c.right-1?'beside':'?'); })()")
      ok(f'card view {k}: labels {lab}; buttons {lay}', 'Play:true' in lab and 'Close:true' in lab and lay==('below' if k=='abc' else 'beside'))
      await pg.evaluate("ABC_DEBUG.S._handView=null; ABC_DEBUG.render()")
    ok('no "Choose where" button', await pg.evaluate("(()=>{ const D=ABC_DEBUG; const i=D.S.you.hand.findIndex(c=>c.cat==='abc'); D.S._handView=i; D.render(); const n=document.querySelectorAll('[data-do=placehand]').length; D.S._handView=null; D.render(); return n===0; })()"))
    c=await pg.evaluate("(()=>{ const D=ABC_DEBUG,S=D.S; const c=JSON.parse(JSON.stringify(DATA.crits.find(x=>x.name==='Adaptation'))); c.cat='crit'; c._new=false; S.you.hand.unshift(c); S._handView=0; D.render(); return 0; })()")
    await pg.wait_for_timeout(200); await pg.evaluate("ABC_DEBUG.S._handView=null; ABC_DEBUG.S.you.hand.shift(); ABC_DEBUG.render()")
    R.extend(['ERR '+e for e in pg._e]); await pg.close()
    # --- drags ---
    pg=await fresh(b); info,first,a=await drag(pg,'abc','#game .bench-mini[data-benchinfo^="you:"]')
    ok(f'ghost appears at the card, not the corner, with no lag transition ({first} vs pointer {a})', first and first[0]>100 and first[1]>100 and abs(first[0]-a[0])<160 and abs(first[1]-a[1])<200 and first[2] in ('0s','0s, 0s'))
    ok(f'ABC → Backstage: zones + short chips, drop opens the question ({info[1][:70]})', info[0]==5 and info[2] and await pg.evaluate("!!document.querySelector('.modal-bg')"))
    R.extend(['ERR '+e for e in pg._e]); await pg.close()
    pg=await fresh(b); info,_,_=await drag(pg,'crit','#game .you-side .lenschip'); ok(f'Lens → slot ({info[1]})', await pg.evaluate("!!ABC_DEBUG.S.you.crit")); await pg.close()
    pg=await fresh(b); info,_,_=await drag(pg,'bm:highlight','#game .char.you'); ok(f'held bookmark → Active ({info[1]})', await pg.evaluate("(ABC_DEBUG.S.you.activeBm||[]).some(c=>c._tag==='highlight')")); await pg.close()
    pg=await fresh(b); info,_,_=await drag(pg,'bm:supercharge','#game .char.you'); ok(f'side bookmark → Active ({info[1]})', await pg.evaluate("(ABC_DEBUG.S.you.activeBm||[]).some(c=>c._tag==='supercharge')")); await pg.close()
    pg=await fresh(b)
    uid=await pg.evaluate("(()=>{ const S=ABC_DEBUG.S; const el=document.querySelector('#game .bench-mini[data-benchinfo^=\"you:\"]'); const u=el.dataset.benchinfo.split(':')[1]; const ch=S.you.team.find(c=>c.uid===u); ch.hp=Math.max(10,ch.hp-40); ABC_DEBUG.render(); return u; })()")
    hp0=await pg.evaluate(f"ABC_DEBUG.S.you.team.find(c=>c.uid==='{uid}').hp")
    info,_,_=await drag(pg,'bm:heal','#game .bench-mini[data-benchinfo^="you:"]')
    r=await pg.evaluate(f"[ABC_DEBUG.S.you.team.find(c=>c.uid==='{uid}').hp, !!ABC_DEBUG.S.picker]")
    ok(f'instant Heal dropped on a Backstage ally heals that ally, no question ({info[1][:60]}; hp {hp0}->{r[0]})', r[0]>hp0 and not r[1]); await pg.close()
    pg=await fresh(b); info,_,_=await drag(pg,'bm:f77_rip_bench','#game .bench-mini[data-benchinfo^="opp:"]', up=False)
    ok(f'enemy-reserve bookmark targets the opponent\'s Backstage ({info[0]} zones, hot={info[2]})', info[0]>=1 and info[2]); await pg.mouse.up(); await pg.wait_for_timeout(300)
    ok('…and resolves without a question', await pg.evaluate("!ABC_DEBUG.S.picker")); await pg.close()
    pg=await fresh(b); n0=await pg.evaluate("ABC_DEBUG.S.you.hand.length"); info,_,_=await drag(pg,'abc',(60.0,420.0))
    ok('drop outside: card returns, nothing opens', await pg.evaluate("!document.querySelector('.modal-bg') && !document.querySelector('.dd-ghost') && !document.querySelector('.dd-ring')")); await pg.close()
    # --- character cards (drawn mode) ---
    pg=await fresh(b, drawn=True)
    await pg.evaluate("ABC_DEBUG.drawnFlipAll()"); await pg.wait_for_timeout(900); await pg.evaluate("ABC_DEBUG.drawnKeepHand()"); await pg.wait_for_timeout(900)
    ci=await pg.evaluate("ABC_DEBUG.S.you.hand.findIndex(c=>c.cat==='char')")
    info,_,_=await drag(pg,ci,'#game .you-side', up=False); 
    ok(f'character card → empty board: "{info[1]}"', 'Active' in info[1] and info[2]); await pg.mouse.up(); await pg.wait_for_timeout(500)
    ok('…becomes your Active', await pg.evaluate("ABC_DEBUG.drawnHasActive(ABC_DEBUG.S.you)"))
    await pg.wait_for_timeout(1800)   # let the draw-phase animation finish (it sets busy) before taking over
    await pg.evaluate("(()=>{ const S=ABC_DEBUG.S; ABC_DEBUG.freeze(); ABC_DEBUG.busy=false; S.turn='you'; if(S.phase!=='place') S.phase='strategize'; ABC_DEBUG.render(); })()"); await pg.wait_for_timeout(200)
    await pg.evaluate("ABC_DEBUG.busy=false")
    ci=await pg.evaluate("""(()=>{ const P=ABC_DEBUG.S.you, key=c=>c.fe?((c._cdef&&c._cdef.base)||[])[1]:(c.charId||c.id);   /* one copy of a character in play: pick one not already on the field */
      const on=P.team.filter(c=>c.hp>0).map(c=>(c.fe&&c.base)?c.base[1]:c.id); return P.hand.findIndex(c=>c.cat==='char' && on.indexOf(key(c))<0); })()""")
    if ci>=0:
      n=await pg.evaluate("ABC_DEBUG.S.you.team.length")
      zr=await pg.evaluate("(()=>{ const r=document.querySelector('#game .you-side .bench').getBoundingClientRect(); return [r.left+r.width/2, r.top+r.height/2]; })()"); info,_,_=await drag(pg,ci,tuple(zr), up=False); 
      ok(f'second character → Backstage: "{info[1]}"', 'Backstage' in info[1] and info[2]); await pg.mouse.up(); await pg.wait_for_timeout(500)
      ok('…joins the Backstage', await pg.evaluate(f"ABC_DEBUG.S.you.team.length==={n}+1"))
    R.extend(['ERR '+e for e in pg._e]); await pg.close()
    # --- phone: view fits, buttons beside, lens readable (stacked) ---
    pg=await b.new_page(viewport={'width':390,'height':844}, has_touch=True, is_mobile=True); pg._e=[]; pg.on('pageerror',lambda e: pg._e.append(str(e)))
    await pg.goto(URL); await pg.wait_for_timeout(1000); await pg.evaluate("ABC_DEBUG.startBattle()"); await pg.wait_for_timeout(3000)
    i=await pg.evaluate(GIVE,'crit'); await pg.evaluate(f"ABC_DEBUG.S._handView={i}; ABC_DEBUG.render()"); await pg.wait_for_timeout(250)
    r=await pg.evaluate("(()=>{ const v=document.querySelector('.hand-view').getBoundingClientRect(), a=document.querySelector('.hv2-acts').getBoundingClientRect(); const fs=Math.min(...[...document.querySelectorAll('.hv2-lens .pfl-pan')].map(p=>parseFloat(getComputedStyle(p).fontSize))); return {fit:v.top>=0&&v.bottom<=innerHeight&&a.right<=innerWidth, fs, sw:document.documentElement.scrollWidth}; })()")
    ok(f'phone: card view fits the screen, lens text {r["fs"]}px, no sideways scroll', r['fit'] and r['fs']>=12.5 and r['sw']<=390)
    R.extend(['ERR '+e for e in pg._e]); await pg.close()
    ok('no page errors', not any(x.startswith('ERR') for x in R))
    print('\n'.join(R)); print(sum(r.startswith('PASS') for r in R),'/',len(R)); globals()['_FAILS']=sum(r.startswith('FAIL') for r in R); await b.close()
asyncio.run(m())
import sys; sys.exit(1 if globals().get('_FAILS') else 0)
