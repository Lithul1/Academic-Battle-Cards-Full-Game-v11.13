# ABC — fix_scrim_tome handoff (2026-11-04)

**Why:** this is the first of three Literary Scrimmage patches. It brings the mode in line with the rest of the game as an "old tome / D&D" campaign book.
- Trevor chose Concept A (Adventurer's Tome) from `scrim_tome_preview.html`, with C's illuminated style reserved for bosses (patch 3).
- The anachronistic Algorithm theme stays.
- The in-game preview (`make_st_preview.py`) was approved, and Trevor played a full Act I in Safari with no stutters.

**Needs:** the Literary Scrimmage code (`scrimMapScreen`, `scrimDrawConnectors`, `scrimAdvanceAct`). Chain-tested after fix_cardface_evolve.
**Install:** `python3 fix_scrim_tome.py && python3 build.py`.
**Rules:** no game rule changes. Every Scrimmage action keeps its `data-scrim` command.

## Changes (CSS before `</style>\n</head>`, JS before `function menuScreen(){`, Google Fonts link extended)
- **Fonts:** the existing Google Fonts link gains IM Fell English (+SC) and Cinzel. vcheck reports "original lines missing: 1"; that's this line, and it's expected.
- **Map** (`scrimMapScreen` reassigned):
  - **Quick-access bar** above the book: "‹ Scrimmage menu" (`endrun`, which saves the run) and "🏛 Shop" (`data-st="shop"`, which saves first, then opens the Vault on the Shop tab).
  - **Left page:** party character sheets (portrait, archetype, HP bar, HP badge), the ledger (Deck button → `rundeck`, Intellect, Late Fees, Act/Semester), relics, and a map key.
  - **Map key compatibility:** the key keeps the "MAP GUIDE" text and one `class="glg"` item per node type, so `tools/validate.js`'s notebook-legend check still passes.
  - **Right page:** the route. `#smap` holds the `.smap-col` rows; nodes keep the `smap-node <type> pos/reach/done` classes and gain `.st-seal`, with a glyph per type in `ST_GLYPH`.
- **Ink** (`scrimDrawConnectors` reassigned): curved SVG paths.
  - Walked roads are red, roads open from your position are solid ink, the rest are faint dotted.
  - A teal party token sits on the current seal.
  - Tall routes auto-scroll to the party.
- **Travel effect:** a capture-phase click on a reachable seal inks the road and moves the token over `abcPace(700)` ms (about 385ms on Fast), stamps the seal, then calls `handleScrim(cmd)`.
  - It's skipped under calm-fx, Instant speed and Reduce motion.
  - `ST.busy` blocks double clicks.
- **New Act:** `scrimAdvanceAct` is wrapped and sets `ST.turn`, so the route page turns in (rotateY 0.75s).
- **Vault:** `scrimVaultShell` is wrapped to add a teal "↩ Resume run" ribbon tab whenever a run is saved. The tabs are restyled as red ribbon bookmarks, with the current tab in gold.
- **All Scrimmage panels** (`.scrim-panel`, `.vbody`) become parchment leaves: IM Fell titles with a ✦ rule, red "wax" primary buttons, and outlined option buttons. Kits get red seal icons. The page background is a dark desk.
- **Battles inside a run:** `render` is wrapped to toggle `body.st-table` when `APP.mode==='scrim'` on the play screen. That gives a dark wooden table plus `#stCandles`: two small flickering candles in the bottom corners, opacity-only, hidden on phones.
- **Phones:** the route page comes first, then the party page; the ribbon, page numbers and the "saved" note are hidden.

Debug export: `window.ABC_ST={st, glyph, table}`.

## Tests
- New: `test_scrim_tome.py` (30 checks). It covers:
  - fonts
  - the map structure on desktop and phone: a seal per node, a road per link, the token, a sheet per character, no sideways scroll
  - the Shop and Scrimmage menu buttons, including saving
  - the Resume ribbon returning to the same map position
  - the tome styling on the Vault, rest, fair and defeat pages
  - travel inking the road, stamping the seal and then resolving the node
  - the table skin appearing only in run battles
  - Instant speed skipping the animation
- Full suite: 24/25 in the full run. The one miss was test_cardplay's known discard-flight timing check under load, which passes standalone (18/18). validate.js: 8/8.

## Next (agreed order)
- **Patch 2, Quests + Oaths:**
  - one quest per Act, chosen from three
  - available on every difficulty, with goal and reward scaled to Honors / Doctoral tier
  - optional Oath handicaps for an IP multiplier
  - the active quest shown on the map's left page
- **Patch 3, d20 encounters + boss reveals:**
  - event choices become checks against a difficulty number, plus archetype bonuses, plus a trivia bonus for a correct answer
  - boss reveal pages in the illuminated (Concept C) style
