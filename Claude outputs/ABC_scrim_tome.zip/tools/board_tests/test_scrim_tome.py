import asyncio, os, pathlib
_ROOT = pathlib.Path(__file__).resolve().parents[2]
URL = (pathlib.Path(os.environ.get('ABC_STUB', _ROOT / 'dist' / 'stub.html')).resolve()).as_uri()
_CHROME = os.environ.get('ABC_CHROME')
def _launch_kw(): return {'executable_path': _CHROME} if _CHROME else {}
from playwright.async_api import async_playwright
R=[]; ok=lambda n,c: R.append(('PASS' if c else 'FAIL')+'  '+n)
async def to_map(pg):
  await pg.evaluate("localStorage.removeItem('abc_scrim_run'); ABC_DEBUG.scrimOpen()"); await pg.wait_for_timeout(250)
  await pg.evaluate("ABC_DEBUG.handleScrim('new')"); await pg.wait_for_timeout(150)
  await pg.evaluate("ABC_DEBUG.handleScrim('kit:gothic')"); await pg.wait_for_timeout(500)
async def main():
  async with async_playwright() as p:
    b=await p.chromium.launch(**_launch_kw())
    for w,h,touch,tag in [(1280,800,False,'desk'),(390,844,True,'phone')]:
      pg=await b.new_page(viewport={'width':w,'height':h},has_touch=touch,is_mobile=touch); errs=[]; pg.on('pageerror',lambda e: errs.append(str(e)))
      await pg.goto(URL); await pg.wait_for_timeout(1000)
      ok(f'{tag} Google Fonts link adds IM Fell English + Cinzel', await pg.evaluate("[...document.querySelectorAll('link[href*=\"fonts.googleapis\"]')].some(l=>/IM\\+Fell\\+English/.test(l.href)&&/Cinzel/.test(l.href))"))
      await to_map(pg)
      r=await pg.evaluate("""(()=>{ const m=ABC_DEBUG.SCRIM.map; const n=m.cols.reduce((a,c)=>a+c.length,0), links=m.cols.reduce((a,c,i)=>a+(i<m.cols.length-1?c.reduce((b,x)=>b+(x.next||[]).length,0):0),0);
        return {tome:!!document.querySelector('.st-tome'), seals:document.querySelectorAll('.st-tome .smap-node.st-seal').length, n, paths:document.querySelectorAll('#smapLines path.st-ink').length, links,
          token:!!document.querySelector('#smapLines .st-token'), sheets:document.querySelectorAll('.st-sheet').length, team:ABC_DEBUG.SCRIM.team.length, sw:document.documentElement.scrollWidth, reach:document.querySelectorAll('.smap-node.reach').length}; })()""")
      ok(f'{tag} map is the open campaign book: a seal per node, an inked road per link, token, a sheet per character ({r})', r['tome'] and r['seals']==r['n'] and r['paths']==r['links'] and r['token'] and r['sheets']==r['team'] and r['reach']>0)
      ok(f'{tag} no sideways scroll', r['sw']<=w)
      ok(f'{tag} quick-access bar: Scrimmage menu + Shop', await pg.evaluate("!!document.querySelector('.st-bar [data-scrim=\"endrun\"]') && !!document.querySelector('.st-bar [data-st=\"shop\"]')"))
      pos0=await pg.evaluate("JSON.stringify(ABC_DEBUG.SCRIM.map.pos)")
      await pg.click('.st-bar [data-st="shop"]'); await pg.wait_for_timeout(300)
      s=await pg.evaluate("[ABC_DEBUG.SCRIM.view, ABC_DEBUG.SCRIM.vaultTab, !!localStorage.getItem('abc_scrim_run'), !!document.querySelector('.vtab.st-resume')]")
      ok(f'{tag} Shop button saves the run and opens the Vault shop, with a Resume ribbon ({s})', s[0]=='shop' and s[1]=='shop' and s[2] and s[3])
      await pg.click('.vtab.st-resume'); await pg.wait_for_timeout(400)
      ok(f'{tag} Resume ribbon returns to the same spot on the map', await pg.evaluate(f"ABC_DEBUG.SCRIM.view==='map' && JSON.stringify(ABC_DEBUG.SCRIM.map.pos)==={pos0!r} && !!document.querySelector('.st-tome')"))
      await pg.click('.st-bar [data-scrim="endrun"]'); await pg.wait_for_timeout(300)
      ok(f'{tag} Scrimmage menu button saves and goes to the Scrimmage menu', await pg.evaluate("ABC_DEBUG.SCRIM.view==='intro' && !!localStorage.getItem('abc_scrim_run') && !!document.querySelector('.vtabs')"))
      ok(f'{tag} tome pages: Vault uses the tome type and ribbon tabs', await pg.evaluate("/IM Fell/.test(getComputedStyle(document.querySelector('.vtab')).fontFamily+getComputedStyle(document.querySelector('.vbody')).fontFamily+getComputedStyle(document.querySelector('.vtab')).fontFamily) || /Cinzel/.test(getComputedStyle(document.querySelector('.vtab')).fontFamily)"))
      for v in ['rest','fair','dead']:
        await pg.evaluate(f"(()=>{{ ABC_DEBUG.SCRIM.view='{v}'; ABC_DEBUG.APP.screen='scrim'; ABC_DEBUG.render(); }})()"); await pg.wait_for_timeout(120)
        ok(f'{tag} {v} page is a tome leaf', await pg.evaluate("/IM Fell/.test(getComputedStyle(document.querySelector('.scrim-title')).fontFamily) && getComputedStyle(document.querySelector('.scrim-panel')).backgroundImage.indexOf('gradient')>=0"))
      ok(f'{tag} no page errors', not errs); await pg.close()
    # travel effect + node resolves; table skin only in run battles; page turn
    pg=await b.new_page(viewport={'width':1280,'height':800}); errs=[]; pg.on('pageerror',lambda e: errs.append(str(e)))
    await pg.goto(URL); await pg.wait_for_timeout(1000); await to_map(pg)
    v0=await pg.evaluate("[ABC_DEBUG.SCRIM.view, ABC_DEBUG.APP.screen]")
    await pg.click('.st-tome .smap-node.reach'); await pg.wait_for_timeout(150)
    mid=await pg.evaluate("[!!document.querySelector('#smapLines .st-draw'), !!document.querySelector('.smap-node.st-stamp')]")
    ok(f'travel inks the road and stamps the seal ({mid})', mid[0] and mid[1])
    await pg.wait_for_timeout(1500)
    v1=await pg.evaluate("[ABC_DEBUG.SCRIM.view, ABC_DEBUG.APP.screen]")
    ok(f'…then the node resolves as before ({v0} → {v1})', v1!=v0)
    if v1[1]=='play':
      ok('a battle inside the run sits on the candlelit table', await pg.evaluate("document.body.classList.contains('st-table') && getComputedStyle(document.getElementById('stCandles')).display!=='none'"))
    await pg.evaluate("ABC_DEBUG.APP.screen='menu'; ABC_DEBUG.APP.mode=null; ABC_DEBUG.render()"); await pg.wait_for_timeout(200)
    await pg.evaluate("ABC_DEBUG.startBattle()"); await pg.wait_for_timeout(2500)
    ok('a normal (non-Scrimmage) battle has no table skin', await pg.evaluate("!document.body.classList.contains('st-table')"))
    await pg.evaluate("ABC_DEBUG.APP.screen='menu'; ABC_DEBUG.APP.mode=null; ABC_DEBUG.render()"); await to_map(pg)
    await pg.evaluate("localStorage.setItem('abc_speed','instant')"); 
    v0=await pg.evaluate("[ABC_DEBUG.SCRIM.view, ABC_DEBUG.APP.screen]")
    await pg.click('.st-tome .smap-node.reach'); await pg.wait_for_timeout(120)
    ok('Instant speed skips the travel animation', await pg.evaluate("[ABC_DEBUG.SCRIM.view, ABC_DEBUG.APP.screen]")!=v0)
    await pg.evaluate("localStorage.removeItem('abc_speed')")
    ok('no page errors (travel/battle)', not errs); await pg.close()
    print('\n'.join(R)); print(sum(r.startswith('PASS') for r in R),'/',len(R)); globals()['_FAILS']=sum(r.startswith('FAIL') for r in R); await b.close()
asyncio.run(main())
import sys; sys.exit(1 if globals().get('_FAILS') else 0)
