# ABC — fix_scrim_quests handoff (2026-11-05)

**Why:** this is Literary Scrimmage patch 2 of 3: Quests and Oaths. Approved in preview (`make_qo_preview.py`).
**Trevor's calls:**
- The reward sizes are fine for now.
- Quests are previewed before a kit is picked.
- Keep the 11 quests and 4 oaths; more can be generated later.

**Needs:** fix_scrim_tome.py, and fix_challenges.py for its event stream.
**Install:** `python3 fix_scrim_quests.py && python3 build.py`.
**Rules:** no rule of play changes.

## Player-facing
- **Genre Kit page:** an "Act I · On the Notice Board" panel shows the three quests (goal and reward) and the two Oaths before a kit is chosen. Changing the Honors tier rescales the goals but keeps the same quests. The run then offers exactly these.
- **Start of each Act (each Semester in a Doctoral run):** the Notice Board lies over the map as a sheet.
  - Pick one of three quests and optionally swear one of two Oaths. "Set out ›" is locked until a quest is chosen.
  - The map behind can't be clicked until then. The Scrimmage menu and Shop buttons are on the sheet.
- **Quests** pay the moment they're fulfilled, with a "QUEST FULFILLED" banner over the map or a battle. Frugal Scholar and Field Medic are judged when the Act's boss falls.
- **Oaths** pay bonus IP when the Act's boss falls if kept. Breaking one shows an "OATH BROKEN" banner and only loses the bonus.
- **Map left page:** the quest (progress bar) and the oath (Sworn / Kept / Broken) sit above Relics.

## Data (in `QO_QUESTS` / `QO_OATHS`; add more as entries)

| Item | Normal / I / II / III |
|---|---|
| Tier | `min(3, honors + (doctoral ? 1 : 0))` |
| Quest IP | 25 / 35 / 50 / 70 |
| Extra-IP quests | ×1.6 IP instead of an item |
| Late-Fee quests | 6 / 8 / 10 / 12 fees |
| Relic quests | `scrimGrantArtifact`: common/uncommon at Normal and I, uncommon/rare at II and III; +20 IP if no relic is left to give |
| Oath bonus | 30 / 45 / 65 / 90 IP |

**Quests:**

| Quest | Goal (n per tier) |
|---|---|
| unbroken | streak of wins with no knockout |
| recite | streak of correct answers |
| bookworm | Bookmarks played |
| thesis | Lens theses fulfilled |
| swift | win within n of your turns |
| scourge | statuses inflicted |
| carto | distinct node types visited |
| frugal | Late Fees held at the boss |
| medic | everyone alive and above half HP at the boss |
| flourish | n plays in one turn |
| slayer | beat a Thesis Defense; from tier 2, without a knockout |

**Oaths:**

| Oath | Rule |
|---|---|
| unplugged | no Coffee Break |
| austerity | no Book Fair purchase |
| ironwill | no knockout |
| ascetic | no Study Break card |

## Engine (all wrappers by reassignment; Scrimmage runs only: `APP.mode==='scrim'`, not `S._sim`)
- `abcChEv` is wrapped and feeds `qoEv` before the Daily Challenge eligibility gate, so attach-house-rules don't matter. Events used: answer, bookmark/play, thesis, status, win, activeKO.
- `abcChKO`: a Backstage knockout also counts as a knockout.
- `abcChTurn` counts your turns and resets plays per turn. A new battle is detected when `S` changes.
- `abcChEnd(win, boss)` triggers `qoActEnd` (end-of-Act quests and the oath payout).
- `scrimResolveNode`: places visited, and Coffee Break visits (unplugged).
- `handleScrim`: `fairbuy` breaks austerity only when Late Fees actually dropped; `draftpick` breaks ascetic only when the deck grew.
- `scrimScreen`: the board overlays the map while `SCRIM.quest` is missing, belongs to another Act, or isn't set.
- `scrimMapScreen`: the ledger is inserted before Relics.
- `scrimKitScreen`: the Act I preview panel.
- Save:
  - `scrimSave` / `scrimLoadSave` / `scrimClearSave` keep `SCRIM.quest` under localStorage `abc_scrim_quest`.
  - `scrimStartKit` resets it and carries the kit-page offers (`SCRIM._qoPre` → `_qoPreUse`) into Act I.
- Payouts are guarded (`done` / `paid` / `oathPaid`), so nothing pays twice.
- Debug export: `window.ABC_QO={qo, quests, oaths, tier, fresh, complete, actEnd, ev}`.
- `tools/validate.js` still passes, because the map (with its "MAP GUIDE") renders under the board.

## Tests
- New: `test_scrim_quests.py` (24 checks). It covers:
  - the board on desktop and phone, and the board lifting after Set out
  - real Bookworm progress from a bookmark played in a Scrimmage battle
  - payout once, with its banner
  - Unplugged broken by a real click on a Coffee Break
  - oath bonus once; Iron Will
  - the Recitation reset; Frugal judged at the boss
  - save and resume
  - a new Act's board, with the map blocked behind it
  - the kit-page preview: tier rescale, same offers carried into the run
  - Honors II scaling
- Changed: `test_scrim_tome.py`; its map helper now picks a quest and sets out when the board is up.
- Full suite: 26/26 (the tome suite after this update). validate.js: 8/8.

## Next
Patch 3: d20 encounters (event choices become checks against a difficulty number, with archetype bonuses and a trivia bonus for a correct answer) and boss reveals in the illuminated Concept C style.
