# Handoff: book menu (fix_menu_book.py)

This is Concept A from the menu preview, as approved, with two additions borrowed from the other concepts:
- the ACT tabs as section headings
- the dealt-card entrance for the two featured buttons

It needs no other patch. If fix_challenges is applied, the menu also shows the challenge streak and the claim badge.

## What it does
- **Left page:**
  - The crest and the title.
  - Two featured buttons. On a first visit: **Start here: Watch the Tutorial**, then Quickplay. Afterwards: **Continue reading: <last mode>**, then Quickplay. If the last mode was Quickplay, the second slot is Literary Scrimmage instead.
  - A daily-challenge strip: streak, today's x/3 done, and rewards to claim. Tapping it opens Challenges.
- **Right page:** the table of contents.
  - Three sections: ACT I Play, ACT II Campaign, ACT III Study. The ACT tab colours match the printed card frames.
  - Roman numerals, dotted leaders, and page numbers (the numbers are decorative).
  - Hover draws an ink underline and shows a one-line description. On phone the descriptions are always shown.
- **Ribbon:** marks your last chapter, or the Tutorial on a first visit.
  - The last mode is stored in `localStorage abc_lastmode`.
  - It's set by Quickplay, Custom Play, Pagemaster, PreCon Arena and Literary Scrimmage only.
- **Choosing a chapter:**
  - Plays `SFX.card('book_flip')` and turns the page over 0.55s.
  - The original click runs again at 0.3s, while the page is mid-turn.
  - With Calm effects or the system reduced-motion setting, there's no animation and the action runs at once.
- **Background:** the menu sits on the board's dark table. Sub-screens keep their current art.
- **Phone:** the two pages stack into one.
- **Unchanged:** every button keeps its existing `data-do`, so no handler changed. No assets are added.

## Hooks
- 1 early return in `menuScreen()`. The old menu stays underneath as the fallback.
- The JS block goes before `menuScreen`, plus the CSS.
- A capture-phase click listener on `.mb [data-do]` handles remembering the last mode, the sound and the page turn.

## Tests
- `test_menu_book.py`: 36 checks across desktop and phone. They cover:
  - all 10 actions present
  - the featured logic
  - ribbon placement
  - page turn, then the action runs once
  - Calm effects runs the action immediately
  - no horizontal scroll
  - the dark table background

## Follow-ups
- **Playable tutorial:** when it exists, point the first-visit button at it instead of the video.
- **Sub-screens:** difficulty, custom, Arena setup and Scrimmage could get the same paper and typography in a second, smaller patch.
