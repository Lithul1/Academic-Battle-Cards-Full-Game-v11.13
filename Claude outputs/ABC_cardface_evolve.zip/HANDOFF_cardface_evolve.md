# ABC — fix_cardface_evolve handoff (2026-11-04)

**Why:** Trevor asked for three things, all approved in preview (`make_cf_preview.py`):
- board Active cards should show the archetype on the right strip, as in the precon preview
- evolution cards should drag onto the card they evolve from
- a new card back

**Needs:** fix_dragdrop_cards.py.
**Install:** `python3 fix_cardface_evolve.py && python3 build.py`.
**Writes:** `src/game.src.html` and `assets/assets.json`; both get a `.bak_<stamp>`.

## Changes
1. **HP + archetype strip** (`abcPfStrip(ch)`, inserted into the Active card template before `.pips`)
   - It reuses the precon preview's `.pcz-hp` / `.pcz-arch` elements, with the same cqw geometry because the frame is drawn identically.
   - The extra classes `.pfs-hp` / `.pfs-arch` are hidden everywhere except `body.abc-arena[data-screen=play] .side .char.pf`.
   - Frame cards only (1st Edition, Gatsby, R&J). Both your Active and the opponent's get it.
   - Text is white with a shadow on 1st Edition frames.
   - Backstage minis skip it (Trevor's call).
2. **Evolution drag** (wraps `abcDdKind`, `abcDdTargets`, `abcDdAct`, `actPick`, `abcDdEnd`)
   - `cat:'act'` cards drag. Zones are `actTargets(you, act)` on the board, Active or Backstage.
   - Eligible: label "Evolve X → Act name". Not eligible: red zone labelled with `actCanEvolve().why`; dropping there shows that reason as a toast and the card returns.
   - Drop: `ABC_EVO.uid` is set, then `tryPlayHandCard` runs. The `actPick` wrapper returns the dropped-on character when it is eligible, so the climax-question gate and all other evolve rules still run unchanged.
   - Tap keeps the old automatic choice: Active first.
3. **Card back**
   - Trevor's PNG became 375×525 WebP with alpha (34 KB) in a fresh asset slot (a1162 in the test bundle; the patch picks max+1).
   - `window.CARD_BACK` now points to it. The old JPEG back (a956) is removed from assets.json after the patch confirms nothing references it.
   - CSS: card backs with an image drop the teal box (the art has its own black rounded rim), and the deck's stacked edges become cream with a black rim.
   - vcheck reports two expected differences: "asset placeholders identical: false" (956 → new id) and "original lines missing: 1" (the CARD_BACK line).

Debug export: `window.ABC_CF={strip, evo}`.

## Tests
- New: `test_cardface_evolve.py` (14 checks). It covers:
  - the strip on both Actives, desktop and phone (values, right-hand position, vertical text)
  - Backstage skipped
  - the new back loads at 375×525
  - evolution drag: eligible evolves the dropped-on character; not-yet shows the reason and is refused
- Full suite: 23/24 suites in the full run. The one miss was test_cardplay's discard-flight timing check, which also missed under load before this patch; it passes 3/3 standalone with this patch applied.
