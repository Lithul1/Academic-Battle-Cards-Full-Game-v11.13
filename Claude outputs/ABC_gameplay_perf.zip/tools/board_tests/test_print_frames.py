import asyncio
import os, pathlib
_ROOT = pathlib.Path(__file__).resolve().parents[2]
STUB_URL = (pathlib.Path(os.environ.get('ABC_STUB', _ROOT / 'dist' / 'stub.html')).resolve()).as_uri()
_CHROME = os.environ.get('ABC_CHROME')
def _launch_kw(): return {'executable_path': _CHROME} if _CHROME else {}
from playwright.async_api import async_playwright

SETUP = """(()=>{ D=ABC_DEBUG; D.freeze(); D.busy=false; const S=D.S;
  const mk=(deck,id)=>D.makeChar(DATA.characters[deck].find(c=>c.id===id),1);
  const fe=(id)=>D.makeChar(DATA.firsteds.find(f=>f.id===id),1);
  S.you.setKey='gatsby'; S.opp.setKey='romeojuliet';
  S.you.team=[mk('gatsby','gatsby'),fe('gatsby_1e'),mk('gatsby','daisy'),mk('hamlet','hamlet'),mk('gatsby','tom')];
  S.opp.team=[mk('romeojuliet','romeo'),fe('romeo_1e'),fe('macbeth_1e'),mk('romeojuliet','mercutio'),mk('romeojuliet','tybalt')];
  S.you.activeIdx=0; S.opp.activeIdx=0; S.you.team[0].hp-=30; S.you.team[0]._tookHit=true; S.turn='you'; S.phase='strategize';
  S.you.hand=[{cat:'act',actId:'gatsby_the_host_of_west_egg',_new:false},{cat:'act',actId:'romeo_husband_of_juliet',_new:false}].concat(S.you.hand.slice(0,3));
  S.you.hand.forEach(c=>c._new=false); D.render(); })()"""
EVO = """(([side,ti,aid])=>{ const P=ABC_DEBUG.S[side], a=DATA.acts.find(x=>x.id===aid), c=P.team[ti];
  c.name=a.name; c.maxHp=a.hp; c.hp=a.hp; c.atk=a.atk; c.blk=a.blk; c.act=a.act; c._actId=a.id; if(a.passive) c.passive=a.passive; ABC_DEBUG.render(); })"""
PFV = """(sel)=>{ const e=document.querySelector(sel); if(!e) return null; return (e.style.getPropertyValue('--pf')||'').replace(/\\s/g,''); }"""
BEFORE = """(sel)=>{ const e=document.querySelector(sel); return e?getComputedStyle(e,'::before').backgroundImage:''; }"""

async def main():
  async with async_playwright() as p:
    b = await p.chromium.launch(**_launch_kw())
    res = []; ok = lambda n, c: res.append(('PASS' if c else 'FAIL') + '  ' + n)
    for vw, vh, touch, t in [(1280, 720, False, 'desk'), (390, 844, True, 'phone')]:
      ctx = await b.new_context(viewport={'width': vw, 'height': vh}, has_touch=touch, is_mobile=touch); pg = await ctx.new_page()
      errs = []; pg.on('pageerror', lambda e: errs.append(str(e)))
      await pg.goto(STUB_URL); await pg.wait_for_timeout(600)
      await pg.evaluate("ABC_DEBUG.startBattle()"); await pg.wait_for_timeout(2500)
      await pg.evaluate(SETUP); await pg.wait_for_timeout(300)
      ok(f'{t} frame variables defined for all 7 frames', await pg.evaluate("['fe','gatsby-1','gatsby-2','gatsby-3','romeojuliet-1','romeojuliet-2','romeojuliet-3'].every(k=>getComputedStyle(document.documentElement).getPropertyValue('--pf-'+k).search(/data:image\/webp|blob:/)>=0)"))
      ok(f'{t} Gatsby base Active uses the Gatsby Act I frame', await pg.evaluate(PFV, '.char.you') == 'var(--pf-gatsby-1)')
      ok(f'{t} R&J base Active uses the R&J Act I frame', await pg.evaluate(PFV, '.char.opp') == 'var(--pf-romeojuliet-1)')
      ok(f'{t} Active frame is drawn over the card', 'var' not in (await pg.evaluate(BEFORE, '.char.you')) and 'url(' in (await pg.evaluate(BEFORE, '.char.you')))
      art = await pg.evaluate("(()=>{ const c=document.querySelector('.char.you').getBoundingClientRect(), a=document.querySelector('.char.you .pc-art').getBoundingClientRect(); return [(a.left-c.left)/c.width,(a.width/c.width)]; })()")
      ok(f'{t} portrait sits in the frame art window ({art[0]:.3f}, {art[1]:.3f})', abs(art[0] - .056) < .02 and abs(art[1] - .746) < .03)
      ok(f'{t} live name + HP plate kept', await pg.evaluate("!!document.querySelector('.char.you .pc-plate .pc-name') && document.querySelector('.char.you .pc-hp b').textContent.trim()==='80/110'"))
      mini = await pg.evaluate("[...document.querySelectorAll('.you-side .bench-mini')].map(e=>[e.dataset.benchinfo.split(':')[1].replace(/_[a-z0-9]{5}$/,''), (e.style.getPropertyValue('--pf')||'').trim()])")
      d = dict(mini)
      ok(f'{t} Backstage 1st Edition uses the Special frame', d.get('gatsby_1e') == 'var(--pf-fe)')
      ok(f'{t} Backstage base uses the deck frame', d.get('daisy') == 'var(--pf-gatsby-1)')
      ok(f'{t} a deck without frames keeps its look', d.get('hamlet') == '')
      omini = dict(await pg.evaluate("[...document.querySelectorAll('.opp-side .bench-mini')].map(e=>[e.dataset.benchinfo.split(':')[1].replace(/_[a-z0-9]{5}$/,''), (e.style.getPropertyValue('--pf')||'').trim()])"))
      ok(f'{t} any deck\'s 1st Edition gets the Special frame (Macbeth 1E)', omini.get('macbeth_1e') == 'var(--pf-fe)')
      await pg.evaluate(EVO, ['you', 0, 'gatsby_the_host_of_west_egg']); await pg.evaluate(EVO, ['opp', 0, 'romeo_husband_of_juliet']); await pg.wait_for_timeout(200)
      ok(f'{t} evolving swaps to the Act II frame', await pg.evaluate(PFV, '.char.you') == 'var(--pf-gatsby-2)' and await pg.evaluate(PFV, '.char.opp') == 'var(--pf-romeojuliet-2)')
      await pg.evaluate(EVO, ['you', 0, 'gatsby_doomed_dreamer']); await pg.wait_for_timeout(200)
      ok(f'{t} Act III frame', await pg.evaluate(PFV, '.char.you') == 'var(--pf-gatsby-3)')
      ok(f'{t} the old ACT badge is hidden on a framed card', await pg.evaluate("(()=>{ const e=document.querySelector('.char.you .act-badge'); return !e || getComputedStyle(e).display==='none'; })()"))
      await pg.evaluate(EVO, ['opp', 1, 'romeo_husband_of_juliet']); await pg.wait_for_timeout(200)
      omini = dict(await pg.evaluate("[...document.querySelectorAll('.opp-side .bench-mini')].map(e=>[e.dataset.benchinfo.split(':')[1].replace(/_[a-z0-9]{5}$/,''), (e.style.getPropertyValue('--pf')||'').trim()])"))
      ok(f'{t} an evolved 1st Edition shows its Act frame', omini.get('romeo_1e') == 'var(--pf-romeojuliet-2)')
      # Act cards in hand
      hc = await pg.evaluate("[...document.querySelectorAll('.hand .hc.pf-hc')].map(e=>(e.style.getPropertyValue('--pf')||'').trim())")
      ok(f'{t} Act cards in hand are framed ({len(hc)})', 'var(--pf-gatsby-2)' in hc and 'var(--pf-romeojuliet-2)' in hc)
      ok(f'{t} framed Act card keeps its evolve condition + data-idx', await pg.evaluate("(()=>{ const e=document.querySelector('.hand .hc.pf-hc'); return !!e.querySelector('.act-cond') && e.dataset.idx!=null; })()"))
      # Inspect dossier
      await pg.evaluate("ABC_DEBUG.S._benchView={side:'you',uid:ABC_DEBUG.S.you.team[0].uid}; ABC_DEBUG.render()"); await pg.wait_for_timeout(300)
      dz = await pg.evaluate("""(()=>{ const K=document.querySelector('.pcz')?'pcz':'pfz'; const z=document.querySelector('.'+K); if(!z) return null; return {k:K, nm:z.querySelector('.'+K+'-name').textContent.trim(), hp:z.querySelector('.'+K+'-hp').textContent.replace(/\\s/g,''), tr:z.querySelector('.'+K+'-trig').textContent, mv:z.querySelectorAll('.'+K+'-m').length, pas:!!z.querySelector(K==='pcz'?'.pcz-pas':'.pfz-p'), live:document.querySelector('.'+K+'-live b').textContent, close:!!document.querySelector('.pf-dossier [data-do=benchclose]'), chg:!!document.querySelector('.pf-dossier .bv-chg')}; })()""")
      ok(f'{t} Inspect shows the full printed-style card', bool(dz) and dz['nm'] == 'Doomed Dreamer' and dz['hp'] in ('HP160', '160HP') and dz['mv'] == 2 and dz['pas'])
      ok(f'{t} dossier trigger line (plot point, or the printed endgame line after fix_print_cards)', bool(dz) and (('climax question' in dz['tr'] and 'Tragic' in dz['tr']) or dz['tr'] == 'None - this is the endgame.'))
      ok(f'{t} dossier keeps live HP, charges and Close', bool(dz) and dz['live'] == '160/160' and dz['chg'] and dz['close'])
      w = await pg.evaluate("document.querySelector('.pcz,.pfz').getBoundingClientRect().width")
      ok(f'{t} dossier card is full width ({round(w)}px)', w > 180)
      await pg.evaluate("ABC_DEBUG.S._benchView={side:'opp',uid:ABC_DEBUG.S.opp.team[2].uid}; ABC_DEBUG.render()"); await pg.wait_for_timeout(300)
      ok(f'{t} 1E dossier drops "(1E)" and prints the deck name', await pg.evaluate("(()=>{ const K=document.querySelector('.pcz')?'pcz':'pfz'; return document.querySelector('.'+K+'-name').textContent.trim()==='Macbeth' && document.querySelector('.'+K+'-deck').textContent==='MACBETH'; })()"))
      await pg.evaluate("ABC_DEBUG.S._benchView=null; ABC_DEBUG.render()"); await pg.wait_for_timeout(700)
      if touch:
        await pg.tap('.you-side .bench-mini:nth-child(2)'); await pg.wait_for_timeout(300)
        ok(f'{t} tapping a framed Backstage card opens its details', await pg.evaluate("!!document.querySelector('.abc-inspect .ai-dossier :is(.pfz,.pcz)')"))
        await pg.evaluate("ABC_DEBUG.S._benchView=null; ABC_DEBUG.render()"); await pg.wait_for_timeout(300)
      else:
        await pg.click('.you-side .bench-mini:nth-child(2)'); await pg.wait_for_timeout(300)
        ok(f'{t} clicking a framed Backstage card opens its details', await pg.evaluate("!!document.querySelector('.abc-inspect .ai-dossier :is(.pfz,.pcz)')"))
        await pg.evaluate("ABC_DEBUG.S._benchView=null; ABC_DEBUG.render()"); await pg.wait_for_timeout(300)
      # boss is never framed
      ok(f'{t} a boss is never framed', await pg.evaluate("(()=>{ const c=ABC_DEBUG.S.opp.team[0]; c._boss=true; ABC_DEBUG.render(); const r=!document.querySelector('.char.opp').classList.contains('pf'); c._boss=false; ABC_DEBUG.render(); return r; })()"))
      # Tune switch
      await pg.evaluate("document.querySelector('[data-do=settings]').click()"); await pg.wait_for_timeout(300)
      has = await pg.evaluate("!!document.querySelector('[data-abcpf]')")
      ok(f'{t} Tune has a Printed card frames switch', has)
      if has:
        await pg.evaluate("(()=>{ document.querySelector('[data-abcpf]').click(); })()"); await pg.wait_for_timeout(200)
        ok(f'{t} switch off: no frames anywhere', await pg.evaluate("localStorage.getItem('abc_pframe')==='off' && !document.querySelector('.pf,.pf-hc,.pfz,.pcz')"))
        await pg.evaluate("localStorage.removeItem('abc_pframe'); ABC_DEBUG.render()")
      ok(f'{t} no page errors', not errs)
      await ctx.close()
    # classic board: the field keeps its look, the dossier is framed
    ctx = await b.new_context(viewport={'width': 1280, 'height': 720}); pg = await ctx.new_page()
    errs = []; pg.on('pageerror', lambda e: errs.append(str(e)))
    await pg.goto(STUB_URL); await pg.wait_for_timeout(500)
    await pg.evaluate("localStorage.setItem('abc_layout','classic')")
    await pg.evaluate("ABC_DEBUG.startBattle()"); await pg.wait_for_timeout(2500)
    await pg.evaluate(SETUP); await pg.wait_for_timeout(300)
    ok('classic: field card has no frame drawn', (await pg.evaluate(BEFORE, '.char.you')) in ('none', ''))
    await pg.evaluate("ABC_DEBUG.S._benchView={side:'you',uid:ABC_DEBUG.S.you.team[0].uid}; ABC_DEBUG.render()"); await pg.wait_for_timeout(300)
    ok('classic: dossier modal shows the framed card', await pg.evaluate("!!document.querySelector('.modal-bg :is(.pfz,.pcz)')"))
    ok('classic: no page errors', not errs)
    await ctx.close()
    print('\n'.join(res)); print(sum(r.startswith('PASS') for r in res), '/', len(res)); globals()['_FAILS'] = sum(r.startswith('FAIL') for r in res); await b.close()
asyncio.run(main())
import sys; sys.exit(1 if globals().get('_FAILS') else 0)
