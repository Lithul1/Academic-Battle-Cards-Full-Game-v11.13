# Handoff: gameplay slowdown (fix_gameplay_perf.py)

There are no visual, rules or data changes. It runs after the full current patch stack, last.

## How it was measured
- A full-weight build of about 19 MB, with portrait-sized images in every asset slot.
- CPU slowed 4x in Chromium to stand in for a school laptop or tablet.
- A scripted turn: two trivia attaches, an attack, then the AI's turn, about 18 seconds. Each version was run 3 times.

## Causes found
1. **The whole board was rebuilt on every state change.** `renderGame` used `innerHTML`, so every card, portrait and frame was re-parsed, re-styled, re-laid-out and re-rasterised. Portraits are inlined as base64, so this was about 0.5 MB of markup per render.
2. **The turn timer animated its width.** That forced a layout and repaint of the board about 60 times a second, all turn, even while idle.
3. **`fitNames` was slow.** It shrank names 0.5px at a time, forcing a layout on every step.
4. **Images in CSS variables.** About 40 images (FX sprites, arena art, deck backgrounds, frames) sit in `:root` CSS variables as 40–90 KB data URIs. Every style update compared them, which doubled the cost of each restyle.
5. **Morph wiping the stage scale.** The new morph initially stripped the stage-scale CSS variable on every render, which forced a full restyle. Runtime-set CSS variables are now kept.

## What the patch does
- **`abcMorph`:** builds the same markup but patches only the differences. It's used for `renderGame` and the Inspect panel.
  - CSS variables set by layout code are kept. The markup's own style is remembered per node, so a variable the markup removes really is removed.
  - Escape hatch: `localStorage.abc_morph = 'off'` brings back the old full rebuild.
- **Blob URLs:** after load, images are converted once to short `blob:` URLs, in idle batches of 12ms or less. This covers card data, the image maps, logos and the `:root` image variables. A 1px self-test keeps data URIs anywhere blob URLs aren't allowed.
- **Timer bar:** uses `transform: scaleX` instead of width. The transition is off with Calm effects or reduced motion.
- **`fitNames` fast path:** one measurement, then a jump straight to the fitting size, cached by text, width and base size.
- **Debug export:** `window.ABC_PERF`.

## Results (median of 3 runs)

| Measure | Before | After |
|---|---|---|
| Stalled time (frames over 50ms) | 4.3s | 1.2s (−72%) |
| Janky frames | 24 | 12 |
| Worst frame | ~420ms | ~265ms |
| Frame rate | 45 fps | 54 fps |
| One board render (JS) | 64–143ms | 13–35ms |
| Style + layout per 10 renders | 719ms | 29ms |
| Idle CPU on the board (5s) | 1164ms | 184ms (−84%) |
| Markup per render | 483 KB | 12 KB |

## Tests
- `test_gameplay_perf.py`: 28 checks on desktop and phone. They cover:
  - nodes are kept across renders
  - changed values still show
  - the stage scale survives a render
  - the hand grows and shrinks
  - the log opens and closes
  - the timer uses `scaleX`
  - names fit, including a very long name
  - the blob path (converts once, loads, slims markup, leaves small images alone)
  - the escape hatch
- `test_print_frames.py`: the frame-variable check now accepts `blob:` as well as `data:`.
- Full run: 18/18 suites pass. Validator: 8/8.

## Left on the table (next candidates)
- **Hand hover:** hovering still repaints large box-shadows and the Inspect card. Moving the shadow onto a pseudo-element with an opacity change would make it cheaper.
- **Music:** procedural music (`build`, `piano`, `snare`) runs on the main thread. It could pre-render a few bars into buffers.
- **Pixel FX sprites:** these are drawn with canvas `toDataURL` on first use. They could be pre-baked at load.
