# Handoff: printed cards, part 2 (fix_print_cards.py)

Needs `fix_print_frames.py` applied first. Run order: … → challenges → print_frames → print_cards.

## What it does
- **Character Inspect card**, matched to the Dextrous scans (positions in frame px / 7.5 = cqw):
  - name, HP and archetype in the ribbon
  - the trigger line shows how the card evolves *next*; Act III reads "None - this is the endgame."
  - attack and block badges, with move text in Courier New
  - Act II/III show an "Act I: …" / "Act II: …" caption, and Act III shows "Resolution: Tragic/Comic"
  - passive
- **Phone Inspect** (container 300px or wider): everything is on the card.
- **Desktop Inspect** (narrow): the card is cropped under the trigger bar, and the moves and passive continue underneath in the same printed style. Every line appears once; nothing is repeated.
- **Inspect background:** the panel is now paper on every deck, which fixes dark text on dark deck art.
- **PreCon Arena hand characters** are framed. The `dminfo` details button, the Active/Bench `dmplace` buttons and `data-idx` are kept.
- **Bookmarks** use the printed layout, coloured by kind:

  | Kind | Colour |
  |---|---|
  | Boost | leaf green `#2f5f1c` |
  | Item | blue `#22344a` |
  | Support | dark brown `#2d2523` |
  | Status | forest green `#0f3a22` |
  | Utility | light brown `#7a4c1d` |
  | Reset | red `#5f1224` |
  | Legendary (any kind) | black |

  - Rarity mark: C circle, U triangle, R star, E gem, L crown.
  - The 10 Bookmarks without art show a placeholder mark.
- **Critical Lens** uses Trevor's frame:
  - the name sits right of the CRITICAL LENS tab, with the art in the window
  - Passive/Thesis/Reward go in the dark panels; on desktop the panels continue below the art
  - shown in your hand and in the Inspect column, which keeps the thesis button and adds a Close
- **Off switch:** Tune > "Printed card frames" restores the old look for everything here.
- **Assets:** 1 new asset slot, for the Lens frame (600px WebP, about 30 KB).

## Hooks
- 5 one-line early returns:
  - `benchInfoModal`, placed before the print_frames one
  - `handCard`, three times: Lens, Arena character, Bookmark
- 1 edited line: the Inspect lens line now tries `abcPcLensInsp` before `critChip`.
- JS block goes before `menuScreen`, plus the CSS.
- New CSS class prefixes: `pcz-*` (character), `pfb-*` (Bookmark), `pfl-*` (Lens), `pc-*`.

## Tests
- `test_print_cards.py`: 50 checks, desktop and phone.
- `test_print_frames.py` now accepts either dossier style. It passes 55/55 both with and without this patch.
- Full run: 15/15 suites pass.
- `validate.js --full`: 8/8.
- DATA block is byte-identical. The 437 existing placeholders are kept and 1 is added.

## Notes
- The printed values differ from the game data for Daisy:
  - Act II attack: 40 printed, 50 in data
  - Act III attack: 40+ printed, 50+ in data
  - Act I trigger: printed as "Discard 2 ⚔ after 1 turn"; in data she evolves on taking damage
  
  The game shows the data.
- The HP on the card is the in-game max HP. The engine rounds HP to the nearest 10 (85 becomes 90).
- Card number and character rarity aren't in the data yet, so they're not shown.
