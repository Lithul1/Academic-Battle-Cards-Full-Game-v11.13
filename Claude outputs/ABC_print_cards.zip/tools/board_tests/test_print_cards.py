import asyncio
import os, pathlib
_ROOT = pathlib.Path(__file__).resolve().parents[2]
STUB_URL = (pathlib.Path(os.environ.get('ABC_STUB', _ROOT / 'dist' / 'stub.html')).resolve()).as_uri()
_CHROME = os.environ.get('ABC_CHROME')
def _launch_kw(): return {'executable_path': _CHROME} if _CHROME else {}
from playwright.async_api import async_playwright

SETUP = """(()=>{ D=ABC_DEBUG; D.freeze(); D.busy=false; const S=D.S;
  const mk=(deck,id)=>D.makeChar(DATA.characters[deck].find(c=>c.id===id),1);
  const fe=(id)=>D.makeChar(DATA.firsteds.find(f=>f.id===id),1);
  S.you.setKey='gatsby'; S.opp.setKey='romeojuliet';
  S.you.team=[mk('gatsby','daisy'),fe('daisy_1e'),mk('gatsby','gatsby'),mk('hamlet','hamlet')];
  S.opp.team=[mk('romeojuliet','romeo'),fe('romeo_1e')];
  S.you.activeIdx=0; S.opp.activeIdx=0; S.turn='you'; S.phase='strategize'; S.you.crit=null;
  const bm=(pred)=>{ const b=JSON.parse(JSON.stringify(DATA.bookmarks.find(pred))); b.cat='bookmark'; b._new=false; return b; };
  const lens=JSON.parse(JSON.stringify(DATA.crits[0])); lens.cat='crit'; lens._new=false;
  window.__fe=DATA.firsteds.find(f=>f.id==='daisy_1e'); window.__gd=DATA.characters.gatsby.find(c=>c.id==='gatsby');
  S.you.hand=[bm(b=>b.kind==='BOOST'), bm(b=>b.kind==='ITEM'), bm(b=>b.kind==='SUPPORT'), bm(b=>b.kind==='STATUS'), bm(b=>b.kind==='UTILITY'&&b.rarity!=='L'), bm(b=>b.kind==='RESET'&&b.rarity!=='L'), bm(b=>b.rarity==='L'), lens,
    {cat:'char', name:'Jay Gatsby', _cdef:window.__gd, _new:false}, {cat:'char', name:'Daisy Buchanan (1E)', _cdef:window.__fe, _new:false}];
  D.render(); })()"""
EVO = """(([ti,aid])=>{ const c=ABC_DEBUG.S.you.team[ti], a=DATA.acts.find(x=>x.id===aid);
  c.name=a.name; c.maxHp=a.hp; c.hp=a.hp; c.atk=a.atk; c.blk=a.blk; c.act=a.act; c._actId=a.id; c.archetype=a.archetype; if(a.passive) c.passive=a.passive; else delete c.passive; ABC_DEBUG.render(); })"""
OPEN = "((i)=>{ ABC_DEBUG.S._benchView={side:'you',uid:ABC_DEBUG.S.you.team[i].uid}; ABC_DEBUG.render(); })"
CARD = """(()=>{ const z=document.querySelector('.pc-dossier .pcz'); if(!z) return null; const q=s=>{ const e=z.querySelector(s); return e?e.textContent.trim():null; };
  const r=z.getBoundingClientRect(), bv=getComputedStyle(document.querySelector('.pc-dossier')).backgroundColor;
  return {nm:q('.pcz-name'), hp:q('.pcz-hp'), arch:q('.pcz-arch'), trig:q('.pcz-trig'), prev:q('.pcz-prev'), res:q('.pcz-res'), mv:z.querySelectorAll('.pcz-m').length, pas:q('.pcz-pas h4'), deck:q('.pcz-deck'),
    w:r.width, h:r.height, bg:bv, mvText:[...z.querySelectorAll('.pcz-m p')].map(p=>getComputedStyle(p).display), font:getComputedStyle(z.querySelector('.pcz-m p')).fontFamily}; })()"""

async def main():
  async with async_playwright() as p:
    b = await p.chromium.launch(**_launch_kw())
    res = []; ok = lambda n, c: res.append(('PASS' if c else 'FAIL') + '  ' + n)
    for vw, vh, touch, t in [(1280, 720, False, 'desk'), (390, 844, True, 'phone')]:
      ctx = await b.new_context(viewport={'width': vw, 'height': vh}, has_touch=touch, is_mobile=touch); pg = await ctx.new_page()
      errs = []; pg.on('pageerror', lambda e: errs.append(str(e)))
      await pg.goto(STUB_URL); await pg.wait_for_timeout(600)
      await pg.evaluate("ABC_DEBUG.startBattle()"); await pg.wait_for_timeout(2500)
      await pg.evaluate(SETUP); await pg.wait_for_timeout(300)
      # ---- character dossier ----
      await pg.evaluate(OPEN, 0); await pg.wait_for_timeout(250)
      c = await pg.evaluate(CARD)
      ok(f'{t} Act I dossier is the printed card', bool(c) and c['nm'] == 'Daisy Buchanan' and c['hp'].replace(' ', '') == str(await pg.evaluate('ABC_DEBUG.S.you.team[0].maxHp'))+'HP' and c['arch'] == 'Monument')
      ok(f'{t} Act I trigger = how it evolves next', bool(c) and c['trig'] in ('Takes damage.', 'Climax question answered correctly.'))
      ok(f'{t} move text uses Courier New', bool(c) and 'Courier New' in c['font'])
      ok(f'{t} dossier sits on paper (not deck art)', bool(c) and c['bg'] == 'rgb(243, 232, 205)')
      if t == 'desk':
        ok(f'desk narrow Inspect crops the card (moves continue below, h/w {c["h"]/c["w"]:.2f})', c['mvText'] == ['block', 'block'])
      else:
        ok(f'phone card keeps print proportions (h/w {c["h"]/c["w"]:.2f})', abs(c['h'] / c['w'] - 1.4) < .02 and c['mvText'] == ['block', 'block'])
      await pg.evaluate(EVO, [0, 'daisy_the_golden_girl']); await pg.evaluate(OPEN, 0); await pg.wait_for_timeout(200)
      c = await pg.evaluate(CARD)
      ok(f'{t} Act II shows "Act I: <base>" caption', bool(c) and c['prev'] == 'Act I: Daisy Buchanan')
      ok(f'{t} Act II trigger = Act III condition', bool(c) and c['trig'] == 'Climax question answered correctly.')
      await pg.evaluate(EVO, [0, 'daisy_careless_fool']); await pg.evaluate(OPEN, 0); await pg.wait_for_timeout(200)
      c = await pg.evaluate(CARD)
      ok(f'{t} Act III trigger reads the endgame line', bool(c) and c['trig'] == 'None - this is the endgame.')
      ok(f'{t} Act III shows Resolution + "Act II:" caption + passive', bool(c) and 'Resolution: Tragic' in (c['res'] or '') and (c['prev'] or '').startswith('Act II: ') and bool(c['pas']))
      await pg.evaluate(OPEN, 1); await pg.wait_for_timeout(200)
      c = await pg.evaluate(CARD)
      ok(f'{t} 1E dossier: Special frame, no "(1E)", deck name in footer', bool(c) and c['nm'] == 'Daisy Buchanan' and (c['deck'] or '') == 'THE GREAT GATSBY' and await pg.evaluate("document.querySelector('.pcz').classList.contains('pf-fe')"))
      await pg.evaluate(OPEN, 3); await pg.wait_for_timeout(200)
      ok(f'{t} deck without frames keeps the old dossier', await pg.evaluate("!document.querySelector('.pcz') && !!document.querySelector('.bench-view')"))
      ok(f'{t} dossier still has charges + Close', await pg.evaluate("(()=>{ ABC_DEBUG.S._benchView={side:'you',uid:ABC_DEBUG.S.you.team[0].uid}; ABC_DEBUG.render(); return !!document.querySelector('.pc-dossier .bv-chg') && !!document.querySelector('.pc-dossier [data-do=benchclose]'); })()"))
      await pg.evaluate("ABC_DEBUG.S._benchView=null; ABC_DEBUG.render()"); await pg.wait_for_timeout(200)
      # ---- bookmarks ----
      k = await pg.evaluate("[...document.querySelectorAll('.hand .hc.pfb')].map(e=>[...e.classList].filter(x=>x.startsWith('k-')||x.startsWith('r-')).join(' '))")
      ok(f'{t} all 7 Bookmarks use the printed layout ({len(k)})', len(k) == 7)
      bgs = await pg.evaluate("[...document.querySelectorAll('.hand .hc.pfb .pfb-in')].map(e=>getComputedStyle(e).backgroundColor)")
      want = ['rgb(47, 95, 28)', 'rgb(34, 52, 74)', 'rgb(45, 37, 35)', 'rgb(15, 58, 34)', 'rgb(122, 76, 29)', 'rgb(95, 18, 36)', 'rgb(11, 10, 9)']
      ok(f'{t} colour by kind: boost/item/support/status/utility/reset/legendary', bgs == want)
      ok(f'{t} Bookmark keeps data-idx, playable state and rarity mark', await pg.evaluate("(()=>{ const e=document.querySelector('.hand .hc.pfb'); return e.dataset.idx==='0' && (e.classList.contains('playable')||e.classList.contains('spent')) && !!document.querySelector('.hand .hc.pfb .pfb-rar'); })()"))
      ok(f'{t} Bookmark shows name, BOOKMARK spine, kind and text', await pg.evaluate("(()=>{ const e=document.querySelector('.hand .hc.pfb'); return !!e.querySelector('.pfb-name').textContent && e.querySelector('.pfb-side').textContent==='BOOKMARK' && e.querySelector('.pfb-foot b').textContent==='BOOST' && e.querySelector('.pfb-foot p').textContent.length>5; })()"))
      # ---- lens ----
      ok(f'{t} Lens in hand uses the frame', await pg.evaluate("!!document.querySelector('.hand .hc.pc-lens .pfl')"))
      nm = await pg.evaluate("(()=>{ const n=document.querySelector('.hand .pc-lens .pfl-name'), c=document.querySelector('.hand .pc-lens .pfl'); return [n.offsetLeft/c.offsetWidth, n.offsetTop/c.offsetWidth]; })()")
      ok(f'{t} Lens name sits right of the CRITICAL LENS tab ({nm[0]:.2f}, {nm[1]:.2f})', nm[0] > .25 and nm[1] < .1)
      await pg.evaluate("(()=>{ const S=ABC_DEBUG.S; S.you.crit=JSON.parse(JSON.stringify(DATA.crits[0])); S.you._lensOpen=true; ABC_DEBUG.render(); })()"); await pg.wait_for_timeout(250)
      lz = await pg.evaluate("(()=>{ const e=document.querySelector('.pc-lensinsp'); if(!e) return null; return {pan:[...e.querySelectorAll('.pfl-pan')].map(p=>p.textContent.trim().length>3), th:!!e.querySelector('[data-do=thesis]'), close:!!e.querySelector('[data-do^=\"lens:\"]')}; })()")
      ok(f'{t} Lens Inspect: printed card with Passive/Thesis/Reward, thesis button, close', bool(lz) and lz['pan'] == [True, True, True] and lz['th'] and lz['close'])
      vis = await pg.evaluate("[...document.querySelectorAll('.pc-lensinsp .pfl-pan')].map(p=>{ const r=p.getBoundingClientRect(); return r.height>12 && getComputedStyle(p).display!=='none'; })")
      ok(f'{t} Lens panel text is visible', vis == [True, True, True])
      await pg.evaluate("(()=>{ const S=ABC_DEBUG.S; S.you._lensOpen=false; S.you.crit=null; ABC_DEBUG.render(); })()")
      # ---- Arena hand characters ----
      ch = await pg.evaluate("[...document.querySelectorAll('.hand .hc.pc-char')].map(e=>[(e.style.getPropertyValue('--pf')||'').trim(), e.dataset.idx, !!e.querySelector('[data-do^=\"dminfo:\"]'), e.querySelector('.hcc-nm').textContent])")
      ok(f'{t} Arena hand characters framed (deck + Special frame)', len(ch) == 2 and ch[0][0] == 'var(--pf-gatsby-1)' and ch[1][0] == 'var(--pf-fe)')
      ok(f'{t} hand character keeps data-idx, details button, clean name', all(x[1] is not None and x[2] for x in ch) and ch[1][3] == 'Daisy Buchanan')
      await pg.evaluate("ABC_DEBUG.S.phase='place'; ABC_DEBUG.render()"); await pg.wait_for_timeout(150)
      ok(f'{t} placing: Active / Bench buttons kept', await pg.evaluate("document.querySelectorAll('.hand .hc.pc-char [data-do^=\"dmplace:\"]').length===4"))
      await pg.evaluate("ABC_DEBUG.S.phase='strategize'; ABC_DEBUG.render()")
      # ---- off switch ----
      await pg.evaluate("localStorage.setItem('abc_pframe','off'); ABC_DEBUG.render()"); await pg.wait_for_timeout(150)
      ok(f'{t} Tune off restores every old card', await pg.evaluate("!document.querySelector('.pfb,.pc-lens,.pc-char,.pcz')"))
      await pg.evaluate("localStorage.removeItem('abc_pframe'); ABC_DEBUG.render()")
      ok(f'{t} no page errors', not errs)
      await ctx.close()
    print('\n'.join(res)); print(sum(r.startswith('PASS') for r in res), '/', len(res)); globals()['_FAILS'] = sum(r.startswith('FAIL') for r in res); await b.close()
asyncio.run(main())
import sys; sys.exit(1 if globals().get('_FAILS') else 0)
