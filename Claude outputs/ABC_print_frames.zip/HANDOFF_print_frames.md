# Handoff: printed-card frames in game (fix_print_frames.py)

## What it does

- **Which cards get frames**
  - The Great Gatsby and Romeo & Juliet base characters get their deck's Act I frame, including non-evolving characters.
  - Act II and Act III cards get their deck's Act II / Act III frame. The frame changes when the card evolves.
  - Every deck's 1st Editions share the Special frame. An evolved 1E shows the Act frame, like the printed Act card laid on top of it.
  - Bosses, decks without frames, and the classic board's field cards are unchanged.
- **Where frames show**
  - Active card and Backstage minis: Arena board, desktop and phone.
  - Inspect dossier: the full printed-style card, on any board layout, including the classic modal.
  - Act cards in your hand, plus the hover preview in Inspect.
- **How a card is built**
  - Each frame's art window is transparent: the portrait sits under the frame, and the Act II cracks and Act III lightning draw over it.
  - Name, HP, archetype, trigger line and moves are live text.
  - On the field, the name and live HP plate cover the frame's trigger bar.
  - **Dossier on narrow screens** (desktop Inspect, about 200px wide): the card shows move names and costs, and the full rules text sits underneath.
  - **Dossier on wide screens** (phone and classic modal, 300px or more): the rules text prints on the card itself.
- **Off switch:** Tune > "Printed card frames" (`localStorage abc_pframe`).

## Assets

- 7 frames, each 600px wide, WebP q80: 327 KB raw, about 436 KB once built.
- They go into **7 new asset slots**. The patch picks the next free ids by looking at both `src/game.src.html` and `assets/assets.json`; in the test repo these were a1154–a1160.
- The patch writes both files and backs up both.

## Hooks

- 6 one-line edits, nothing removed:
  - `charTile`: adds a class and a CSS variable.
  - `benchTiles`: adds a class and an inline CSS variable.
  - `benchInfoModal`: returns early when the card is framed.
  - `actHandCard`: returns early when the card is framed.
  - A Tune row, plus its handler in the `input` listener.
- Also adds the JS block (inserted before `menuScreen`), the CSS, and a `:root` block of `--pf-*` variables.
- **Frame selection:** `abcPfKey(c)`. The deck comes from the act (`_actId`), then `c.deck`, then `c.base[0]`, then the id's deck in `DATA.characters`.
- **Adding frames for another deck:**
  1. Add its 3 frames as asset slots and `--pf-<deck>-1/2/3` variables.
  2. Add `<deck>:{acts:[1,2,3]}` to `PF_DECKS`.

## Order and tests

- Run order: after challenges. Prerequisites: board v1–v6 and three-act evolution.
- `test_print_frames.py`: 55 checks (desktop, phone, classic). Full run: 14/14 suites pass.
- `validate.js --full`: 8/8.
- DATA block byte-identical; all 430 existing asset placeholders kept, 7 added.
- Applying the patch a second time is refused. Without `assets/assets.json` or the board patches, it refuses and writes nothing.

## Known and accepted

- The swap button on a framed mini sits on the card's top-left corner, so a tap on the middle of the card opens details.
- It covers the small ACT label on the tab.
- Text positions are matched by eye to the frames. A finished Dextrous scan per frame type would let them match exactly.
- Character cards in your hand in PreCon Arena are not framed. That wasn't in the agreed scope, and it's a small follow-up.
