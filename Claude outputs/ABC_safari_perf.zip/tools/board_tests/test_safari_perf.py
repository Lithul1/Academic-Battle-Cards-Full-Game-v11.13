import asyncio, base64, os, pathlib
_ROOT = pathlib.Path(__file__).resolve().parents[2]
STUB_URL = (pathlib.Path(os.environ.get('ABC_STUB', _ROOT / 'dist' / 'stub.html')).resolve()).as_uri()
_CHROME = os.environ.get('ABC_CHROME')
def _launch_kw(): return {'executable_path': _CHROME} if _CHROME else {}
from playwright.async_api import async_playwright

def big_png(seed):
  import zlib, struct, random
  random.seed(seed); w, h = 100, 100
  raw = b''.join(b'\x00' + bytes(random.getrandbits(8) for _ in range(w * 3)) for _ in range(h))
  def ch(t, d): return struct.pack('>I', len(d)) + t + d + struct.pack('>I', zlib.crc32(t + d) & 0xffffffff)
  png = b'\x89PNG\r\n\x1a\n' + ch(b'IHDR', struct.pack('>IIBBBBB', w, h, 8, 2, 0, 0, 0)) + ch(b'IDAT', zlib.compress(raw, 1)) + ch(b'IEND', b'')
  return 'data:image/png;base64,' + base64.b64encode(png).decode()

async def main():
  async with async_playwright() as p:
    b = await p.chromium.launch(**_launch_kw())
    res = []; ok = lambda n, c: res.append(('PASS' if c else 'FAIL') + '  ' + n)
    for vw, vh, touch, t in [(1280, 720, False, 'desk'), (390, 844, True, 'phone')]:
      ctx = await b.new_context(viewport={'width': vw, 'height': vh}, has_touch=touch, is_mobile=touch); pg = await ctx.new_page()
      errs = []; pg.on('pageerror', lambda e: errs.append(str(e)))
      await pg.goto(STUB_URL); await pg.wait_for_timeout(900)
      ok(f'{t} patch present', await pg.evaluate("!!window.ABC_SF && !!window.ABC_PERF"))
      # 1. conversion is async through fetch: first call returns the data URI, later calls the blob
      r = await pg.evaluate("""(async(big)=>{ const P=ABC_PERF; const u0=P.blobUrl(big); const h0=P.slimHtml('<img src="'+big+'">');
        await new Promise(r=>setTimeout(r,400)); const u1=P.blobUrl(big), u2=P.blobUrl(big); const h1=P.slimHtml('<img src="'+big+'">');
        const im=new Image(); const w=await new Promise(r=>{ im.onload=()=>r(im.naturalWidth); im.onerror=()=>r(-1); im.src=u1; });
        return {first:u0===big, h0:h0.indexOf('base64')>0, blob:u1.startsWith('blob:'), cached:u1===u2, slim:h1.indexOf('blob:')>0&&h1.indexOf('base64')<0, w, idle:ABC_SF.queue.busy===0&&ABC_SF.queue.q.length===0}; })""", big_png(5))
      ok(f'{t} first use leaves the data URI (no sync decode) ({r})', r['first'] and r['h0'])
      ok(f'{t} converted by fetch to a cached blob URL that loads', r['blob'] and r['cached'] and r['slim'] and r['w'] == 100 and r['idle'])
      ok(f'{t} no atob decode loop in the live blob path', await pg.evaluate("ABC_PERF.blobUrl.toString().indexOf('atob')<0"))
      # 2. callbacks: many requests for the same image -> one conversion, every callback gets it
      r = await pg.evaluate("""(async(big)=>{ let n=0, got=[]; for(let i=0;i<5;i++) ABC_SF.blobAsync(big,u=>{ n++; got.push(u); });
        await new Promise(r=>setTimeout(r,400)); return {n, same:got.every(u=>u===got[0]), blob:(got[0]||'').startsWith('blob:')}; })""", big_png(6))
      ok(f'{t} queued once, all callbacks served ({r})', r['n'] == 5 and r['same'] and r['blob'])
      # 3. data walk swaps strings in place
      r = await pg.evaluate("""(async(big)=>{ window.ABC_IMG=window.ABC_IMG||{}; const had=ABC_IMG.__t; ABC_IMG.__t=big; ABC_PERF.slimData();
        await new Promise(r=>setTimeout(r,500)); const v=ABC_IMG.__t; delete ABC_IMG.__t; return v.startsWith('blob:'); })""", big_png(7))
      ok(f'{t} card-data images are swapped to blob URLs after load', r)
      # 3b. pixel strips: created lazily, warmed in the background, every key still resolves to a full strip
      r = await pg.evaluate("""(()=>{ const a=performance.now(); const fx=ABC_PXFX.strips(); const call=performance.now()-a;
        return {call, keys:Object.keys(fx).length, lazy:Object.getOwnPropertyDescriptor(fx,'ko').get!==undefined}; })()""")
      ok(f'{t} pixel strips: first call is instant and lazy ({r})', r['call'] < 30 and r['keys'] >= 30 and r['lazy'])
      await pg.wait_for_timeout(5000)
      r = await pg.evaluate("(()=>{ const fx=ABC_PXFX.strips(), ks=Object.keys(fx); return {drawn:ABC_SF.px.drawn, all:ks.every(k=>fx[k].url.indexOf('data:image/png')===0 && fx[k].frames===( ABC_SF.px.cache[k]||fx[k]).frames), n:ks.length}; })()")
      ok(f'{t} pixel strips warm in the background and all resolve ({r})', r['drawn'] >= 10 and r['all'])
      # 4. gameplay still works with wrapped functions
      await pg.evaluate("ABC_DEBUG.startBattle()"); await pg.wait_for_timeout(2500)
      ok(f'{t} board renders through the wrapped functions', await pg.evaluate("ABC_DEBUG.freeze(); ABC_DEBUG.busy=false; ABC_DEBUG.render(); !!document.querySelector('.char.you')"))
      # 5. meter: force Safari mode (no LoAF), make a slow frame, see js/browser split
      ok(f'{t} meter off: wrappers cost nothing (no timing collected)', await pg.evaluate("(()=>{ ABC_DEBUG.render(); return Object.keys(ABC_SF.timing.names).length===0; })()"))
      await pg.evaluate("localStorage.setItem('abc_perfmeter','on')")
      await pg.reload(); await pg.wait_for_timeout(900)
      await pg.evaluate("ABC_DEBUG.startBattle()"); await pg.wait_for_timeout(2500)
      ok(f'{t} meter shows the script-timing line', await pg.evaluate("!!document.querySelector('#abcPerfMeter .pd-l3')"))
      await pg.evaluate("ABC_PD.state.api='none'; ABC_DEBUG.freeze(); ABC_DEBUG.busy=false")
      await pg.evaluate("""(()=>{ const work=ABC_SF.wrap('testWork',function(){ const t=performance.now(); while(performance.now()-t<120){} }); requestAnimationFrame(()=>work()); })()""")
      await pg.wait_for_timeout(800)
      r = await pg.evaluate("(()=>{ const f=ABC_PD.state.lo.filter(x=>x.js!=null&&x.scripts.some(s=>s.name==='testWork')); const L=f[f.length-1]; return L?{ms:L.ms,js:L.js,br:L.browser,names:L.scripts.map(s=>s.name),l3:document.querySelector('#abcPerfMeter .pd-l3').textContent}:null; })()")
      ok(f'{t} a slow frame is logged with game-script vs browser time and function names ({r})', bool(r) and r['ms'] > 100 and r['js'] >= 110 and r['names'][0] == 'testWork' and 'game script' in r['l3'])
      ok(f'{t} report includes the split', await pg.evaluate("ABC_PD.report().indexOf('\"browser\"')>0"))
      await pg.evaluate("localStorage.removeItem('abc_perfmeter')")
      ok(f'{t} no page errors', not errs)
      await ctx.close()
    print('\n'.join(res)); print(sum(r.startswith('PASS') for r in res), '/', len(res)); globals()['_FAILS'] = sum(r.startswith('FAIL') for r in res); await b.close()
asyncio.run(main())
import sys; sys.exit(1 if globals().get('_FAILS') else 0)
