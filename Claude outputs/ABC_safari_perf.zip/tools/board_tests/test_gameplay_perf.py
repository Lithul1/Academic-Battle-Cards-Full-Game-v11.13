import asyncio, base64, io, os, pathlib
_ROOT = pathlib.Path(__file__).resolve().parents[2]
STUB_URL = (pathlib.Path(os.environ.get('ABC_STUB', _ROOT / 'dist' / 'stub.html')).resolve()).as_uri()
_CHROME = os.environ.get('ABC_CHROME')
def _launch_kw(): return {'executable_path': _CHROME} if _CHROME else {}
from playwright.async_api import async_playwright

# a real ~20 KB PNG as a data URI, so the blob path is exercised (stub images are 1 px and skipped)
def big_png():
  import zlib, struct, random
  random.seed(3); w, h = 120, 120
  raw = b''.join(b'\x00' + bytes(random.getrandbits(8) for _ in range(w * 3)) for _ in range(h))
  def ch(t, d): return struct.pack('>I', len(d)) + t + d + struct.pack('>I', zlib.crc32(t + d) & 0xffffffff)
  png = b'\x89PNG\r\n\x1a\n' + ch(b'IHDR', struct.pack('>IIBBBBB', w, h, 8, 2, 0, 0, 0)) + ch(b'IDAT', zlib.compress(raw, 1)) + ch(b'IEND', b'')
  return 'data:image/png;base64,' + base64.b64encode(png).decode()
BIG = big_png()

async def main():
  async with async_playwright() as p:
    b = await p.chromium.launch(**_launch_kw())
    res = []; ok = lambda n, c: res.append(('PASS' if c else 'FAIL') + '  ' + n)
    for vw, vh, touch, t in [(1280, 720, False, 'desk'), (390, 844, True, 'phone')]:
      ctx = await b.new_context(viewport={'width': vw, 'height': vh}, has_touch=touch, is_mobile=touch); pg = await ctx.new_page()
      errs = []; pg.on('pageerror', lambda e: errs.append(str(e)))
      await pg.goto(STUB_URL); await pg.wait_for_timeout(800)
      await pg.evaluate("ABC_DEBUG.startBattle()"); await pg.wait_for_timeout(2500)
      await pg.evaluate("D=ABC_DEBUG; D.freeze(); D.busy=false; D.render()")
      # 1. the board is patched in place: unchanged nodes survive a render
      same = await pg.evaluate("""(()=>{ const a=document.querySelector('.char.you'), h=document.querySelector('.hand'), s=document.querySelector('.abc-stage'); D.render(); D.render();
        return [a===document.querySelector('.char.you'), h===document.querySelector('.hand'), s===document.querySelector('.abc-stage')]; })()""")
      ok(f'{t} render keeps unchanged board nodes (stage, active card, hand)', same == [True, True, True])
      chg = await pg.evaluate("""(()=>{ const c=D.S.you.team[D.S.you.activeIdx]; c.hp=Math.max(1,c.hp-10); D.render();
        return document.querySelector('.char.you .pc-hp b').textContent===c.hp+'/'+c.maxHp; })()""")
      ok(f'{t} a changed value still shows (HP after damage)', chg)
      ok(f'{t} the stage scale survives a render', await pg.evaluate("(()=>{ const s=document.querySelector('.abc-stage'); const k=s.style.getPropertyValue('--abc-k'); D.render(); return !!k && s.style.getPropertyValue('--abc-k')===k; })()"))
      n0 = await pg.evaluate("D.S.you.hand.length")
      await pg.evaluate("(()=>{ const p=D.S.you; p.hand.push(p.deck.shift()); p.hand[p.hand.length-1]._new=false; D.render(); })()")
      ok(f'{t} hand grows by one card after a draw', await pg.evaluate("document.querySelectorAll('#game .hand .hc').length") == n0 + 1)
      await pg.evaluate("(()=>{ const p=D.S.you; p.deck.unshift(p.hand.pop()); D.render(); })()")
      ok(f'{t} hand shrinks back', await pg.evaluate("document.querySelectorAll('#game .hand .hc').length") == n0)
      # 2. modals still open and close through the morph
      await pg.evaluate("D.S._logopen=true; D.render()")
      ok(f'{t} log opens', await pg.evaluate("document.querySelector('.log').classList.contains('open')"))
      await pg.evaluate("D.S._logopen=false; D.render()")
      ok(f'{t} log closes', await pg.evaluate("!document.querySelector('.log').classList.contains('open')"))
      # 3. turn timer animates with a transform, not width
      tb = await pg.evaluate("(()=>{ D.S.turn='you'; D.S._timeLeft=30; D.S.settings.turnTimer=60; D.render(); const f=document.getElementById('turnbarfill'); return f?[f.style.width, f.style.transform, getComputedStyle(f).transitionProperty]:null; })()")
      ok(f'{t} timer bar uses scaleX ({tb})', bool(tb) and tb[0] == '' and tb[1].startswith('scaleX(0.5') and 'width' not in tb[2])
      # 4. names still fit their plates
      fit = await pg.evaluate("[...document.querySelectorAll('.pc-name')].every(e=>e.scrollWidth<=e.clientWidth+1 || e.classList.contains('pc-wrap'))")
      ok(f'{t} names fit their plates', fit)
      await pg.evaluate("(()=>{ const c=D.S.you.team[D.S.you.activeIdx]; c._nm0=c.name; c.name='Extraordinarily Long Character Name For Testing'; D.render(); })()")
      ok(f'{t} a very long name is shrunk or wrapped', await pg.evaluate("(()=>{ const e=document.querySelector('.char.you .pc-name'); return e.scrollWidth<=e.clientWidth+1 || e.classList.contains('pc-wrap'); })()"))
      await pg.evaluate("(()=>{ const c=D.S.you.team[D.S.you.activeIdx]; c.name=c._nm0; D.render(); })()")
      # 5. images -> blob URLs
      await pg.wait_for_timeout(300)
      bl = await pg.evaluate("""(async(big)=>{ const P=window.ABC_PERF; if(!P) return null; const ok=P.blob.ok;
        P.blobUrl(big); await new Promise(r=>setTimeout(r,400)); /* conversion may be async (fix_safari_perf) */ const u=P.blobUrl(big), u2=P.blobUrl(big); const h=P.slimHtml('<img src="'+big+'">');
        const im=new Image(); const loaded=await new Promise(r=>{ im.onload=()=>r(im.naturalWidth); im.onerror=()=>r(-1); im.src=u; });
        return {ok, blob:u.startsWith('blob:'), cached:u===u2, slim:h.indexOf('blob:')>0 && h.indexOf('base64')<0, loaded}; })""", BIG)
      ok(f'{t} blob URLs: self-test passed, image converts once, loads, and markup is slimmed ({bl})', bool(bl) and bl['ok'] is True and bl['blob'] and bl['cached'] and bl['slim'] and bl['loaded'] == 120)
      ok(f'{t} small images are left alone', await pg.evaluate("(()=>{ const s='<img src=\"data:image/png;base64,iVBORw0KGgo=\">'; return window.ABC_PERF.slimHtml(s)===s; })()"))
      # 6. escape hatch
      await pg.evaluate("localStorage.setItem('abc_morph','off')"); await pg.reload(); await pg.wait_for_timeout(800)
      await pg.evaluate("ABC_DEBUG.startBattle()"); await pg.wait_for_timeout(2500)
      ok(f'{t} escape hatch (abc_morph=off) rebuilds the board the old way', await pg.evaluate("(()=>{ const D=ABC_DEBUG; D.freeze(); D.busy=false; D.render(); const a=document.querySelector('.abc-stage'); D.render(); return a!==document.querySelector('.abc-stage'); })()"))
      await pg.evaluate("localStorage.removeItem('abc_morph')")
      ok(f'{t} no page errors', not errs)
      await ctx.close()
    print('\n'.join(res)); print(sum(r.startswith('PASS') for r in res), '/', len(res)); globals()['_FAILS'] = sum(r.startswith('FAIL') for r in res); await b.close()
asyncio.run(main())
import sys; sys.exit(1 if globals().get('_FAILS') else 0)
