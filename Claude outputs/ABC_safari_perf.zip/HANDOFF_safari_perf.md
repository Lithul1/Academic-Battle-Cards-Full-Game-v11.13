# ABC — fix_safari_perf handoff (2026-11-01)

**Why:** Trevor's meter report came from Safari 27 on an Intel Mac. Safari has no Long Animation Frames API (api "none"), so the meter couldn't name the slow scripts there. His earlier reading was a ~1s freeze (fps 6, 1010ms) shortly after opening the shop; at the time of the report the shop was smooth (fps 126, worst 266ms).

**Needs:** fix_perf_diag.py, which needs fix_gameplay_perf2 → fix_gameplay_perf.
**Install:** `python3 fix_safari_perf.py && python3 build.py`. Undo: restore `src/game.src.html` from the `.bak_*`.

## What changed (one JS block, inserted before `function menuScreen(){`)
1. **Pixel-effect strips are drawn lazily.** This was the main cause. The original `abcPxFx()` drew all 36 sprite strips 1.5s after load in one task (~360ms on a fast PC unthrottled; ~1.4s at 4× CPU throttle; Safari is slower again at 1-px `fillRect`). Now:
   - `abcPxFx` returns an object of lazy getters; each strip is drawn on first access.
   - `abcPxWarm` draws one strip per idle slot. It skips while `.pxo-fx`, `.abc-fly-hand` or `.fly-card` is on screen.
   - `pxPainter` caches `fillStyle`.
   - Strips are byte-identical to before (all 36 data URLs compared).
   - `pxPainter`/`abcPxFx` are *assigned*, not declared, because the originals are declared later in the file and would win the hoist.
2. **Images go to blob: URLs via `fetch(dataURI)`.** This replaces the `atob` + `charCodeAt` loops that produced tens of MB of garbage for Safari's GC.
   - Async queue with concurrency 3: `ABC_BQ`, `abcBlobQueue`, `abcBlobPump`.
   - Redefined: `abcBlobUrl` (returns the cached blob or the data URI and queues it), `abcSlimHtml`, `abcSlimVars` and `abcSlimData` (callback swaps).
3. **Script timing in the meter for Safari/Firefox.**
   - `abcPdWrap` wraps ~32 heavy game functions (render, renderGame, abcMorph, fitBoard, attack/turn/AI functions, fx…). It times them only while the meter is on.
   - A second rAF loop calls `abcPdTick`. Each frame over 50ms is logged with `js`, `browser` (= gap − js: style/layout/paint/GC) and the top 3 functions.
   - A new meter line reads "that frame: game script X ms · browser Y ms".
   - Copy report includes these fields.

## Measured (Chromium, full-weight build, 4× CPU throttle, frames after the load event)
| | worst frame | slow-frame total |
|---|---|---|
| before | 1283–1683ms | 1417–1683ms |
| after | 150–367ms | 733–1083ms |

The blob/fetch change made no measurable difference in Chromium. Its Safari benefit is the GC hypothesis and is unverified (WebKit can't be installed in the sandbox).

## Tests
- New: `test_safari_perf.py` (28 checks). It covers:
  - async conversion, dedupe and data swap
  - wrapped functions render
  - the meter split, with `api` forced to 'none'
  - lazy pixel strips
- Changed: `test_gameplay_perf.py` now waits for the async blob conversion.
- Full suite: 21/21 suites, plus both validators.
- Exports: `window.ABC_SF = {queue, timing, blobAsync, wrap, px}`.

## Next
Ask Trevor for a Safari report with the meter on: after load → shop, and during a match (with tilt on and off). If "browser" dominates, look at Safari-only lite effects (tilt, mix-blend tints, drop-shadow filters).
