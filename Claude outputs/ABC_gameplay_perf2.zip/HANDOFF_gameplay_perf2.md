# Handoff: gameplay lag, part 2 (fix_gameplay_perf2.py)

Run after `fix_gameplay_perf.py`.

## Trevor's report (Mac, local file)
- Waiting after actions
- Choppy animations
- Taps feel delayed

## Findings
- **Waiting after actions** was mostly deliberate pacing:
  - A correct answer played a 1.3s card flight before anything resolved.
  - The AI's turn took about 3.5s of fixed delays plus effects.
- **Choppy:**
  - The attack READY glow (and the thesis-met glow) animated `box-shadow`. That repainted the board 60 times a second for as long as an attack was ready: 241 paints in 4 seconds of idle.
  - The 1st Edition holo and sheen animated `background-position`, which also repaints every frame.
  - Hand hover animated a 24px shadow blur.
- **Sound:** every snare, hat and hit generated fresh random noise samples on the main thread.

## Changes
- **Tune > Animation speed: Fast (new default) / Normal / Instant**
  - Card flight: 650ms / 1300ms / skipped.
  - AI step delays scaled by `abcPace()`: 0.55x / 1x / 0.2x.
  - Normal is exactly the old timing.
  - Stored in `localStorage abc_speed`. `ABC_FLY_MS` is now a `let` set from `abcFlyMsFor()`.
- **Composited glows:** READY and thesis-met are now `::before` rings animating opacity. The 1E holo and sheen are pseudo-elements animating transform. The holo gradient is now horizontal so it can loop without a seam.
- **Hand hover:** only `transform` transitions.
- **Sound:** one shared 2s white-noise buffer per audio context (`abcNoiseBuf`), used by `noise()` and `snare()`.
- **Tune > Performance meter:** a corner readout of fps, worst frame and stutters over the last 3s. It only runs while switched on (`localStorage abc_perfmeter`).
- **Debug export:** `window.ABC_SPEED`.

## Measured
Full-weight build. Compared with before both patches, and with part 1 only.

| Measure | Before | Part 1 | Part 2 |
|---|---|---|---|
| Idle with an attack ready: paints in 4s | 241 | 241 | 0 |
| Answer → card settled | 1.40s | 1.33s | 0.68s |
| End turn → AI done | 3.57s | 3.51s | 2.25s |
| Stalled time per scripted turn (CPU 4x) | 3.3–4.4s | 1.3s | 0.7–0.9s |
| Janky frames | 19–25 | 13 | 7–9 |

## Tests
- `test_gameplay_perf2.py`: 28 checks. It covers:
  - flight length and AI pace for each speed
  - the Tune rows
  - live switching
  - the meter turning on and off
  - the composited READY glow
  - the shared noise buffer
- `test_pixel_fx.py` and `test_cardplay.py` now pin `abc_speed=normal`, because their timings assume the 1.3s flight.
- Full run: 19/19 suites pass. Validator: 8/8.

## Next if lag remains
Ask Trevor for a Performance meter reading during the moment that lags. Candidates:
- the attack effect sequence
- the 3D tilt on Retina screens (toggle tilt off to compare)
- the remaining fixed effect durations in `performAttack`
