import asyncio
import os, pathlib
_ROOT = pathlib.Path(__file__).resolve().parents[2]
STUB_URL = (pathlib.Path(os.environ.get('ABC_STUB', _ROOT / 'dist' / 'stub.html')).resolve()).as_uri()
_CHROME = os.environ.get('ABC_CHROME')
def _launch_kw(): return {'executable_path': _CHROME} if _CHROME else {}
from playwright.async_api import async_playwright
CLEAR="document.querySelectorAll('.cfx,#abcPxCut').forEach(e=>e.remove())"
async def boot(b,vw,vh):
  pg=await b.new_page(viewport={'width':vw,'height':vh}); errs=[]; pg.on('pageerror',lambda e: errs.append(str(e)))
  await pg.goto(STUB_URL); await pg.evaluate("localStorage.setItem('abc_speed','normal')"); await pg.reload(); await pg.wait_for_timeout(700)   # timings below assume Normal animation speed (fix_gameplay_perf2)
  await pg.evaluate("ABC_DEBUG.startBattle()"); await pg.wait_for_timeout(3500)
  await pg.evaluate("D=ABC_DEBUG; D.freeze(); D.busy=false; D.S.turn='you'; D.S.phase='strategize'; D.render()")
  return pg,errs
async def main():
  async with async_playwright() as p:
    b=await p.chromium.launch(**_launch_kw())
    res=[]; ok=lambda n,c: res.append(('PASS' if c else 'FAIL')+'  '+n)
    for vw,vh in [(1280,720),(390,844)]:
      pg,errs=await boot(b,vw,vh); T=f'{vw}x{vh}'
      ok(f'{T} pixel effects on by default', await pg.evaluate("ABC_PXFX.on()"))
      ok(f'{T} 14 sprite strips drawn', await pg.evaluate("Object.keys(ABC_PXFX.strips()).length>=14"))
      # strike: sprite replaces classic art, integer 64px multiple, centred on the card
      await pg.evaluate(CLEAR+"; D.fxAttack('opp',30)"); await pg.wait_for_timeout(120)
      r=await pg.evaluate("""(()=>{ const o=document.querySelector('.cfx.px'), sp=o&&o.querySelector('.cfx-px[data-fx="strike"]'); if(!sp) return null;
        const c=document.querySelector('.char.opp').getBoundingClientRect(), s=sp.getBoundingClientRect();
        return {w:s.width, cls:!!o.querySelector('.cfx-img,.cfx-ring'), num:!!o.querySelector('.cfx-pxnum'), txt:!!o.querySelector('.cfx-float'),
          dx:Math.abs((s.left+s.width/2)-(c.left+c.width/2)), dy:Math.abs((s.top+s.height/2)-(c.top+c.height/2))}; })()""")
      ok(f'{T} strike sprite plays on the opponent card', bool(r))
      ok(f'{T} sprite is a whole multiple of 64px ({r and r["w"]})', bool(r) and r['w']%64==0)
      ok(f'{T} sprite centred on card (off {r and max(r["dx"],r["dy"]):.1f}px)', bool(r) and max(r['dx'],r['dy'])<2)
      ok(f'{T} classic art + text number replaced by pixel number', bool(r) and not r['cls'] and r['num'] and not r['txt'])
      await pg.wait_for_timeout(1300)
      ok(f'{T} effect cleans itself up', await pg.evaluate("!document.querySelector('.cfx')"))
      # crit -> cut-in, sprite held back until the banner clears
      await pg.evaluate(CLEAR+"; D.fxAttack('opp',70)"); await pg.wait_for_timeout(150)
      ok(f'{T} CRITICAL cut-in banner shows', await pg.evaluate("!!document.getElementById('abcPxCut') && document.getElementById('abcPxCut').className==='crit'"))
      ok(f'{T} crit sprite waits for the banner', await pg.evaluate("getComputedStyle(document.querySelector('.cfx-px[data-fx=\"crit\"]')).visibility==='hidden'"))
      ok(f'{T} cut-in never blocks clicks', await pg.evaluate("getComputedStyle(document.getElementById('abcPxCut')).pointerEvents==='none'"))
      await pg.wait_for_timeout(800)
      ok(f'{T} crit sprite visible after banner', await pg.evaluate("getComputedStyle(document.querySelector('.cfx-px[data-fx=\"crit\"]')).visibility==='visible'"))
      await pg.wait_for_timeout(1200)
      ok(f'{T} banner removed', await pg.evaluate("!document.getElementById('abcPxCut')"))
      # KO banner carries the name
      nm=await pg.evaluate("document.querySelector('.char.opp .pc-name').textContent.trim()")
      await pg.evaluate(CLEAR+"; D.fxKO('opp','x')"); await pg.wait_for_timeout(150)
      ok(f'{T} K.O. cut-in shows', await pg.evaluate("(document.getElementById('abcPxCut')||{}).className==='ko'"))
      # mapping of the other effects
      M=[("D.fxBlock('you',20)",'guard'),("D.fxBlock('you',0)",'negate'),("D.fxRevive('you')",'revive'),("ABC_PXFX.heal('you',20)",'heal'),
         ("D.fxStatus('opp','Burn','neg')",'burn'),("D.fxStatus('opp','Tear','neg')",'tear'),("D.fxStatus('opp','Rip','neg')",'rip'),
         ("D.fxStatus('opp','Glue','neg')",'glue'),("D.fxStatus('opp','siphon')",'siphon'),("D.fxStatus('opp','Highlight','pos')",'highlight')]
      for js,k in M:
        await pg.evaluate(CLEAR+"; "+js); await pg.wait_for_timeout(60)
        ok(f'{T} {js} -> {k} sprite', await pg.evaluate(f"!!document.querySelector('.cfx-px[data-fx=\"{k}\"]')"))
      await pg.evaluate(CLEAR+"; D.fxStatus('opp','Stunned','neg')"); await pg.wait_for_timeout(60)
      ok(f'{T} label without a sprite (e.g. a future status) still gets a pixel badge', await pg.evaluate("!!document.querySelector('.cfx-pxnum.badge') && !document.querySelector('.cfx-px')"))
      ok(f'{T} no page errors', not errs)
      await pg.close()
    # attach sparkle lands with the card-play flight
    pg,errs=await boot(b,1280,720)
    await pg.evaluate("""D.S.settings.triviaOn=false; D.S.you.attachesLeft=3; const k=D.S.you.deck.findIndex(c=>c.cat==='abc'); D.S.you.hand.unshift(D.S.you.deck.splice(k,1)[0]); D.S.you.hand.forEach(c=>c._new=false); D.render()""")
    await pg.wait_for_timeout(400)
    await pg.evaluate(CLEAR+"; D.tryPlayHandCard(0)"); await pg.wait_for_timeout(500)
    ok('attach sparkle waits for the flight to land', await pg.evaluate("!document.querySelector('.cfx-px[data-fx=\"attach\"]')"))
    await pg.wait_for_timeout(900)
    ok('attach sparkle plays on the charged card', await pg.evaluate("!!document.querySelector('.cfx-px[data-fx=\"attach\"]')"))
    # Tune switch -> classic, remembered
    await pg.wait_for_timeout(800)
    await pg.click('.tb-btns [data-do="settings"]'); await pg.wait_for_timeout(300)
    ok('Tune row present and checked', await pg.evaluate("document.querySelector('input[data-abcpx]').checked"))
    await pg.click('input[data-abcpx]'); await pg.wait_for_timeout(200)
    ok('switch off -> pixel mode off', not await pg.evaluate("ABC_PXFX.on()"))
    await pg.reload(); await pg.wait_for_timeout(700); await pg.evaluate("ABC_DEBUG.startBattle()"); await pg.wait_for_timeout(3500)
    await pg.evaluate("D=ABC_DEBUG; D.freeze(); D.busy=false; D.render(); "+CLEAR+"; D.fxAttack('opp',30)"); await pg.wait_for_timeout(100)
    ok('off remembered: classic effect markup unchanged', await pg.evaluate("!!document.querySelector('.cfx .cfx-img.strike') && !document.querySelector('.cfx.px')"))
    await pg.evaluate("localStorage.removeItem('abc_pxfx'); document.body.classList.add('calm-fx'); "+CLEAR+"; D.fxAttack('opp',70)"); await pg.wait_for_timeout(100)
    ok('Reduce motion -> classic effect, no cut-in', await pg.evaluate("!document.querySelector('.cfx.px') && !document.getElementById('abcPxCut')"))
    ok('no page errors (attach / toggle)', not errs)
    print('\n'.join(res)); print(sum(r.startswith('PASS') for r in res),'/',len(res)); globals()['_FAILS']=sum(r.startswith('FAIL') for r in res); await b.close()
asyncio.run(main())
import sys; sys.exit(1 if globals().get('_FAILS') else 0)
