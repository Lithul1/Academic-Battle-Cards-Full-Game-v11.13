import asyncio, os, pathlib
_ROOT = pathlib.Path(__file__).resolve().parents[2]
STUB_URL = (pathlib.Path(os.environ.get('ABC_STUB', _ROOT / 'dist' / 'stub.html')).resolve()).as_uri()
_CHROME = os.environ.get('ABC_CHROME')
def _launch_kw(): return {'executable_path': _CHROME} if _CHROME else {}
from playwright.async_api import async_playwright
SET = """(()=>{ D=ABC_DEBUG; D.freeze(); D.busy=false; D.S.turn='you'; D.S.phase='strategize'; D.S.settings.triviaOn=true; D.S.you.attachesLeft=5;
 const k=D.S.you.deck.findIndex(c=>c.cat==='abc'); D.S.you.hand.unshift(D.S.you.deck.splice(k,1)[0]); D.S.you.hand.forEach(c=>c._new=false); D.render() })()"""
FLY = """(async()=>{ D.freeze(); D.busy=false; D.S.turn='you'; D.S.phase='strategize'; D.S.you.attachesLeft=5; D.render(); D.tryPlayHandCard(0); await new Promise(r=>setTimeout(r,250)); if(!D.S.pending) return 'nopending:'+JSON.stringify([D.S.phase,D.busy,D.S.you.hand.length]); D.answerTrivia(D.S.pending.card.ans,true);
  await new Promise(r=>setTimeout(r,60)); const f=document.querySelector('#abcFlyLayer .abc-fly-hand'); const a=f&&f.getAnimations()[0]; return a?Math.round(a.effect.getTiming().duration):0; })()"""
async def main():
  async with async_playwright() as p:
    b = await p.chromium.launch(**_launch_kw())
    res = []; ok = lambda n, c: res.append(('PASS' if c else 'FAIL') + '  ' + n)
    for vw, vh, touch, t in [(1280, 720, False, 'desk'), (390, 844, True, 'phone')]:
      ctx = await b.new_context(viewport={'width': vw, 'height': vh}, has_touch=touch, is_mobile=touch); pg = await ctx.new_page()
      errs = []; pg.on('pageerror', lambda e: errs.append(str(e)))
      for speed, fly, pace in [(None, 650, 220), ('normal', 1300, 400), ('instant', 0, 80)]:
        await pg.goto(STUB_URL); await pg.wait_for_timeout(500)
        await pg.evaluate(f"localStorage.{'removeItem' if speed is None else 'setItem'}('abc_speed'{'' if speed is None else ','+repr(speed)})")
        await pg.reload(); await pg.wait_for_timeout(700)
        nm = speed or 'fast (default)'
        sp = await pg.evaluate("[ABC_SPEED.get(), ABC_SPEED.flyMs(), ABC_SPEED.pace(400)]")
        ok(f'{t} {nm}: card flight {fly} ms, AI step 400 -> {pace} ms ({sp})', sp[1] == fly and sp[2] == pace)
        await pg.evaluate("ABC_DEBUG.startBattle()"); await pg.wait_for_timeout(2500)
        await pg.evaluate(SET); await pg.wait_for_timeout(300)
        d = await pg.evaluate(FLY)
        ok(f'{t} {nm}: the played card flies for {d} ms', d == fly)
        await pg.wait_for_timeout(1600)
      # tune row + switching without reload
      await pg.evaluate("localStorage.removeItem('abc_speed')")
      await pg.evaluate("document.querySelector('[data-do=settings]').click()"); await pg.wait_for_timeout(300)
      ok(f'{t} Tune has Animation speed (Fast selected) and Performance meter', await pg.evaluate("(()=>{ const s=document.querySelector('[data-abcspeed]'); return !!s && s.value==='fast' && !!document.querySelector('[data-abcperf]'); })()"))
      await pg.evaluate("(()=>{ const s=document.querySelector('[data-abcspeed]'); s.value='normal'; s.dispatchEvent(new Event('input',{bubbles:true})); })()")
      ok(f'{t} switching speed applies at once', await pg.evaluate("ABC_SPEED.flyMs()===1300 && localStorage.getItem('abc_speed')==='normal'"))
      await pg.evaluate("document.querySelector('[data-abcperf]').click()"); await pg.wait_for_timeout(700)
      ok(f'{t} performance meter shows fps', await pg.evaluate("(()=>{ const e=document.getElementById('abcPerfMeter'); return !!e && /fps \\d+/.test(e.textContent); })()"))
      await pg.evaluate("document.querySelector('[data-abcperf]').click()"); await pg.wait_for_timeout(200)
      ok(f'{t} performance meter switches off', await pg.evaluate("!document.getElementById('abcPerfMeter') && localStorage.getItem('abc_perfmeter')==='off'"))
      await pg.evaluate("localStorage.removeItem('abc_speed'); ABC_SPEED.set('fast')")
      # composited glow while an attack is ready
      await pg.evaluate("(()=>{ const D=ABC_DEBUG; D.S._settings=null; D.busy=false; D.S.turn='you'; D.S.phase='engage'; const c=D.S.you.team[D.S.you.activeIdx]; while(c.atkCharge.length<c.atk.cost) c.atkCharge.push({type:'ATTACK',power:1}); D.render(); })()")
      await pg.wait_for_timeout(300)
      an = await pg.evaluate("document.getAnimations().map(a=>a.animationName).filter(Boolean)")
      ok(f'{t} READY glow animates opacity on a pseudo-element, no box-shadow pulse ({an})', 'abcRing' in an and 'pulse' not in an)
      ok(f'{t} the ready attack button is still lit', await pg.evaluate("!!document.querySelector('.char.you .pc-move.atk.ready')"))
      nb = await pg.evaluate("(()=>{ const AC=window.AudioContext||window.webkitAudioContext; if(!AC) return 'na'; const c=new AC(); const a=ABC_SPEED.noise(c), b2=ABC_SPEED.noise(c); const r=[a===b2, Math.round(a.duration)]; c.close(); return r; })()")
      ok(f'{t} one shared noise buffer per audio context ({nb})', nb == 'na' or nb == [True, 2])
      ok(f'{t} no page errors', not errs)
      await ctx.close()
    print('\n'.join(res)); print(sum(r.startswith('PASS') for r in res), '/', len(res)); globals()['_FAILS'] = sum(r.startswith('FAIL') for r in res); await b.close()
asyncio.run(main())
import sys; sys.exit(1 if globals().get('_FAILS') else 0)
