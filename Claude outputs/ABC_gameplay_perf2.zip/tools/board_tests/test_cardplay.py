import asyncio
import os, pathlib
_ROOT = pathlib.Path(__file__).resolve().parents[2]
STUB_URL = (pathlib.Path(os.environ.get('ABC_STUB', _ROOT / 'dist' / 'stub.html')).resolve()).as_uri()
_CHROME = os.environ.get('ABC_CHROME')          # optional: path to a Chromium binary
def _launch_kw(): return {'executable_path': _CHROME} if _CHROME else {}
from playwright.async_api import async_playwright
SET="""D=ABC_DEBUG; D.freeze(); D.busy=false; D.S.turn='you'; D.S.phase='strategize'; D.S.settings.triviaOn=false; D.S.you.attachesLeft=3;
 if(!D.S.you.hand.some(c=>c.cat==='abc')) D.S.you.hand.push(D.S.you.deck.find(c=>c.cat==='abc')); D.render()"""
async def main():
  async with async_playwright() as p:
    b=await p.chromium.launch(**_launch_kw())
    res=[]; ok=lambda n,c: res.append(('PASS' if c else 'FAIL')+'  '+n)
    for vw,vh,touch,tag in [(1280,720,False,'desk'),(390,844,True,'phone')]:
      ctx=await b.new_context(viewport={'width':vw,'height':vh},has_touch=touch,is_mobile=touch); pg=await ctx.new_page()
      errs=[]; pg.on('pageerror',lambda e: errs.append(str(e)))
      await pg.goto(STUB_URL); await pg.evaluate("localStorage.setItem('abc_speed','normal')"); await pg.reload(); await pg.wait_for_timeout(700)   # timings below assume Normal animation speed (fix_gameplay_perf2)
      await pg.evaluate("ABC_DEBUG.startBattle()"); await pg.wait_for_timeout(3000)
      await pg.evaluate(SET); await pg.wait_for_timeout(300)
      # ABC attach via the real play path
      i=await pg.evaluate("D.S.you.hand.findIndex(c=>c.cat==='abc')")
      card_n=await pg.evaluate(f"(()=>{{const c=D.S.you.hand[{i}]; window.__c=c; const a=D.S.you.team[D.S.you.activeIdx]; return a.atkCharge.length+a.blkCharge.length}})()")
      await pg.evaluate(f"D.tryPlayHandCard({i})"); await pg.wait_for_timeout(500)
      held=await pg.evaluate("(()=>{const f=document.querySelector('.abc-fly-hand'); return f? f.getBoundingClientRect().width : 0})()")
      fly=await pg.evaluate("document.querySelectorAll('.abc-fly-hand').length")
      await pg.screenshot(path=f'v7_{tag}_mid.png')
      ok(f'{tag} ABC attach: a card is in flight', fly==1)
      ok(f'{tag} card is presented enlarged mid-animation ({held:.0f}px wide)', held>0)
      ok(f'{tag} flying copy ignores clicks', await pg.evaluate("[...document.querySelectorAll('.abc-fly-hand')].every(e=>getComputedStyle(e).pointerEvents==='none')"))
      ok(f'{tag} game state moved on immediately (charge attached)', await pg.evaluate(f"(()=>{{const a=D.S.you.team[D.S.you.activeIdx]; return a.atkCharge.length+a.blkCharge.length>{card_n}}})()"))
      await pg.wait_for_timeout(1500)
      ok(f'{tag} copy cleaned up after landing', await pg.evaluate("document.querySelectorAll('.abc-fly-hand').length===0"))
      # flight end position = the Active card
      # a card that goes to the discard (missed question)
      await pg.evaluate(SET); await pg.wait_for_timeout(100)
      j=await pg.evaluate("D.S.you.hand.findIndex(c=>c.cat==='abc')")
      await pg.evaluate(f"(()=>{{const c=D.S.you.hand[{j}]; window.__m=c; D.S.you.hand.splice({j},1); D.S.you.discard.push(c); D.render();}})()")
      d=await pg.evaluate("""new Promise(res=>{ const go=()=>{ const f=document.querySelector('.abc-fly-hand'); if(!f) return res(998); const an=f.getAnimations()[0]; if(an && an.effect.getComputedTiming().progress<0.9) return requestAnimationFrame(go); const t=document.querySelector('.discardpile[data-pile="you"]'); const a=f.getBoundingClientRect(), b=t.getBoundingClientRect(); res(Math.hypot((a.left+a.width/2)-(b.left+b.width/2),(a.top+a.height/2)-(b.top+b.height/2))); }; go(); })""")
      _unused=await pg.evaluate("""(()=>{const f=document.querySelector('.abc-fly-hand'); const t=document.querySelector('.discardpile[data-pile="you"]'); if(!f||!t) return 999; const a=f.getBoundingClientRect(), b=t.getBoundingClientRect(); return Math.hypot((a.left+a.width/2)-(b.left+b.width/2),(a.top+a.height/2)-(b.top+b.height/2));})()""")
      ok(f'{tag} discarded card lands on the discard pile (centre off by {d:.0f}px)', d<20)
      await pg.wait_for_timeout(900)
      # mulligan-style: many cards leave at once -> no flights
      await pg.evaluate("for(let k=0;k<5;k++) D.dealOne('you'); D.render()"); await pg.wait_for_timeout(1500); await pg.evaluate("D.render()")
      n=await pg.evaluate("D.S.you.hand.length")
      await pg.evaluate("D.S.you.deck=D.S.you.deck.concat(D.S.you.hand.splice(0)); D.render()"); await pg.wait_for_timeout(100)
      ok(f'{tag} {n} cards leaving at once does not animate', await pg.evaluate("document.querySelectorAll('.abc-fly-hand').length===0"))
      # reduce motion -> off
      await pg.evaluate("for(let k=0;k<5;k++) D.dealOne('you'); document.body.classList.add('calm-fx'); D.render()"); await pg.wait_for_timeout(1500); await pg.evaluate("D.render()")
      await pg.evaluate("(()=>{const c=D.S.you.hand[0]; D.S.you.hand.splice(0,1); D.S.you.discard.push(c); D.render();})()"); await pg.wait_for_timeout(100)
      ok(f'{tag} Reduce motion turns it off', await pg.evaluate("document.querySelectorAll('.abc-fly-hand').length===0"))
      ok(f'{tag} no page errors', not errs)
      await ctx.close()
    print('\n'.join(res)); print(sum(r.startswith('PASS') for r in res),'/',len(res)); globals()['_FAILS']=sum(r.startswith('FAIL') for r in res); await b.close()
asyncio.run(main())
import sys; sys.exit(1 if globals().get('_FAILS') else 0)
