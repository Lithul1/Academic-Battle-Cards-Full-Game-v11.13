# Handoff: Performance meter v2 (fix_perf_diag.py)

Diagnostics only, with no gameplay change. Run after `fix_gameplay_perf2.py`.

## Why
Trevor's meter readings, with tilt on:
- **Literary Scrimmage shop:** 6 fps, worst frame 1010ms, 4 stutters.
- **PreCon Arena:** 139 fps (ProMotion display), worst frame 92ms, 5 stutters.

The Scrimmage Vault does not reproduce in the test harness. At 2x pixel density, scrolling every tab (Profile, Shop, 1st Editions, Stacks, Bestiary, Archive), the worst frame was 83ms and no screen ran continuous work. That points at something specific to his machine or browser: real asset sizes, the browser, or memory after a match. The harness uses placeholder images.

## What it does
- **Meter display:**
  - the current screen, e.g. `scrim/shop:shop` or `play`
  - the worst slow frame in the last 10s, split into drawing vs style and layout
  - the busiest script by function name, aggregated over 10s
- **Copy report:** copies JSON with:
  - browser and user agent, screen and pixel ratio, window size
  - current view and body classes
  - DOM size, image count, running animations
  - JS memory (Chrome)
  - animation speed setting
  - the last 25 slow frames, each with its top three scripts
- **Browser support:**
  - Chrome and Edge 123+: Long Animation Frames API, which gives script attribution.
  - Other browsers: long-task timing only. Safari has neither, so it shows fps and worst frame only.
- **Cost:** nothing runs while the meter is off.
- **Implementation:** `abcPerfMeter` is redefined (it overrides the version from `fix_gameplay_perf2`). Debug export: `window.ABC_PD`.

## Tests
- `test_perf_diag.py`: 9 checks. It covers:
  - the meter starting from the saved setting
  - the view name
  - a slow frame reported with its named script
  - the report fields
  - clipboard copy
  - the Scrimmage view name
  - turning the meter off
- Full run: 19/20 suites pass. The one failure is test_phone's "names fit their plates", a flake with randomly chosen decks that was seen before these performance patches. It passes 4 out of 4 on rerun.

## Next
Fix the actual cause from Trevor's pasted report.
