import asyncio, os, pathlib, json
_ROOT = pathlib.Path(__file__).resolve().parents[2]
STUB_URL = (pathlib.Path(os.environ.get('ABC_STUB', _ROOT / 'dist' / 'stub.html')).resolve()).as_uri()
_CHROME = os.environ.get('ABC_CHROME')
def _launch_kw(): return {'executable_path': _CHROME} if _CHROME else {}
from playwright.async_api import async_playwright
async def main():
  async with async_playwright() as p:
    b = await p.chromium.launch(**_launch_kw())
    res = []; ok = lambda n, c: res.append(('PASS' if c else 'FAIL') + '  ' + n)
    ctx = await b.new_context(viewport={'width': 1280, 'height': 720}, permissions=['clipboard-read', 'clipboard-write']); pg = await ctx.new_page()
    errs = []; pg.on('pageerror', lambda e: errs.append(str(e)))
    await pg.goto(STUB_URL); await pg.evaluate("localStorage.setItem('abc_perfmeter','on')"); await pg.reload(); await pg.wait_for_timeout(900)
    ok('meter v2 starts from the saved setting, with a Copy report button', await pg.evaluate("!!document.querySelector('#abcPerfMeter .pd-copy')"))
    ok('meter names the current screen', 'menu/menu' in await pg.evaluate("document.querySelector('#abcPerfMeter .pd-l1').textContent"))
    # make a deliberately slow frame from a named function
    await pg.evaluate("(()=>{ const sc=document.createElement('script'); sc.textContent='function abcTestSlowThing(){ const t=performance.now(); while(performance.now()-t<180){} } setTimeout(abcTestSlowThing, 50);'; document.body.appendChild(sc); })()")
    await pg.wait_for_timeout(1300)
    l2 = await pg.evaluate("document.querySelector('#abcPerfMeter .pd-l2').textContent")
    api = await pg.evaluate("window.ABC_PD.state.api")
    ok(f'a slow frame is reported ({api}): {l2[:90]!r}', 'worst slow frame' in l2)
    if api == 'loaf':
      ok('the busiest script is named', 'abcTestSlowThing' in l2)
    rep = await pg.evaluate("window.ABC_PD.report()")
    j = json.loads(rep.split('\n', 1)[1])
    ok('report has browser, screen, view, DOM size and slow frames', all(k in j for k in ('ua', 'screen', 'view', 'dom', 'slowFrames')) and len(j['slowFrames']) >= 1)
    await pg.click('#abcPerfMeter .pd-copy'); await pg.wait_for_timeout(300)
    clip = await pg.evaluate("navigator.clipboard.readText().catch(()=> '')")
    ok('Copy report puts the report on the clipboard', clip.startswith('ABC PERF REPORT'))
    await pg.evaluate("document.body.classList.add('calm-fx'); document.querySelector('[data-do=go-scrim]').click()"); await pg.wait_for_timeout(1500)
    ok('view shows Scrimmage screens', 'scrim/' in await pg.evaluate("document.querySelector('#abcPerfMeter .pd-l1').textContent"))
    await pg.evaluate("localStorage.setItem('abc_perfmeter','off')")
    await pg.evaluate("(()=>{ const s=window.ABC_PD.state; return 1; })()")
    await pg.reload(); await pg.wait_for_timeout(700)
    ok('meter off: nothing on screen, nothing observing', await pg.evaluate("!document.getElementById('abcPerfMeter') && !window.ABC_PD.state.on"))
    ok('no page errors', not errs)
    await ctx.close()
    print('\n'.join(res)); print(sum(r.startswith('PASS') for r in res), '/', len(res)); globals()['_FAILS'] = sum(r.startswith('FAIL') for r in res); await b.close()
asyncio.run(main())
import sys; sys.exit(1 if globals().get('_FAILS') else 0)
