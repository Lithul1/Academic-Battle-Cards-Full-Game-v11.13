# ABC Daily & Weekly Challenges: Handoff

**Patch:** `fix_challenges.py`. It has no prerequisites: it applies to the original source alone, or on top of the board and pixel patches. It uses the pixel font for its banner when `fix_pixel_fx` is present.

**Design reference:** `challenges_preview.html`, approved.

## What players get

- **Challenges screen:** Main menu → Challenges. The menu button shows a badge with how many rewards are ready to claim.
- **Dailies:** 3 a day (Easy, Medium, Hard), new each local midnight.
- **Weeklies:** 3 a week, new each Monday.
- **Same challenges for everyone on a date:** picked from the date with an FNV hash and a seeded RNG. There's no server.
- **Swap:** one per day, on an unstarted daily.
- **Rewards:** Easy 8, Medium 12, Hard 20, Weekly 40 IP. Claiming all three weeklies unlocks a free Silver pack, which uses the existing `scrimRollPack`, `scrimApplyPack` and `packOverlayShow` flow.
- **Streak:** grows when at least one daily is claimed per day, and resets after a missed day.
- **In a match:** a click-through "CHALLENGE COMPLETE!" banner (z-index 61, about 2.8s). It doesn't animate under Reduce motion.

## Pool

28 challenges in `CH_POOL`, each a plain data entry:

```
{id, fam, tier, name, text, ev, scope, n, distinct?, noMiss?, act?, distinctDeck?, hint?}
```

- **Cards-in-one-turn ladder:** 3 (Easy), 4 (Medium), 5 (Hard), and 6 "Full Hand" (Weekly). Six is the standard-rules maximum: 2 ABC + 2 Bookmarks + 1 Lens + 1 character or Act card.
- **Family rule:** a day never draws two challenges from the same `fam`.
- **Deck-dependent challenges** (Act II/III, Siphon) carry a `hint` naming the decks that can do them. Siphon is weekly-only.

## Engine events

Each hook is one `try{…}catch(e){}` line.

| Hook | Event |
|---|---|
| `chargeReport` | `charge` (+ `play`) |
| `triviaStamp` | `answer {ok}` |
| `playBookmark` `commit()` | `bookmark` (counts as a play) |
| `playCrit` `place()` | `lens` (+ `play`) |
| `fulfillThesis` | `thesis` |
| `actEvolve` | `evolve {act}` (+ `play`) |
| `drawnPlayChar` | `char` (+ `play`) |
| `inflict` (target on the enemy side) | `status {k}` |
| `checkKO` → `abcChKO` | `ko {full}`, or `activeKO` |
| Siphon tick (hp mode, owner is you) | `siphon {uid}` |
| `startTurn` (your turn) | turn counters reset, plus a full-HP snapshot of enemies |
| `overModal` / `scrimOverModal` | `win {deck}` (+ `boss` for a Scrimmage boss), once per match |

**"From full HP in one turn"** means the enemy was at full HP at the start of your turn and was KO'd during that turn.

## Eligibility (`abcChOk`)

Only your side counts, in `APP.mode` quick, scrim or arena, and only when attaches per turn ≤ 2. It never counts when any of these is true:
- `S._sim` (AI vs AI)
- Custom Play or Pagemaster
- the dev panel is open (`APP.dev`)

## Save

Progress is stored in `META.challenges` and saved with `metaSave()`:

```
{day, week, daily[], weekly[], rerolls, streak, lastDone, bonusClaimed}
```

It is **not** in the Transcript Code. Dailies expire on their own, and the frozen `TRANSCRIPT_V2_ORDER` stays untouched. As with all local saves, a determined student could edit it.

## Debug handle

`window.ABC_CH` exposes `{state, ev, end, claimable, scratch, fresh, dailies, weeklies, byId, claim}`.

## Tests

`test_challenges.py`, 36 checks, all through real engine calls:
- **Date logic:** a year of dailies (Easy/Medium/Hard order, never two from the same family); determinism; the streak growing and resetting; the Monday rollover.
- **Cards-in-one-turn:** the ladder via real ABC attaches, Bookmarks and a Lens; the per-turn reset.
- **Other challenges:** the trivia streak and break; KO from full HP; win counted once despite repaints; Untouchable; Siphon distinct enemies; statuses via real attacks; thesis.
- **Eligibility:** Custom Play, sims and 3 attaches don't count.
- **Screen:** claim, swap, the weekly bonus pack, save persistence.

**Full regression:** 13/13 suites, `validate.js` 8/8, `DATA` byte-identical, all 430 asset placeholders preserved.
