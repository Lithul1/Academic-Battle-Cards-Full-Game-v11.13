import asyncio
import os, pathlib
_ROOT = pathlib.Path(__file__).resolve().parents[2]
STUB_URL = (pathlib.Path(os.environ.get('ABC_STUB', _ROOT / 'dist' / 'stub.html')).resolve()).as_uri()
_CHROME = os.environ.get('ABC_CHROME')
def _launch_kw(): return {'executable_path': _CHROME} if _CHROME else {}
from playwright.async_api import async_playwright
# force a known set of challenges for the test day
FORCE="""(([d,w])=>{ const st=ABC_CH.state(); st.daily=d.map(id=>({id,p:0,done:false,claimed:false})); st.weekly=w.map(id=>({id,p:0,done:false,claimed:false})); st.rerolls=[]; })"""
P="((id)=>{ const st=ABC_CH.state(); const c=[...st.daily,...st.weekly].find(x=>x.id===id); return c?c.p:-1; })"
DONE="((id)=>{ const st=ABC_CH.state(); const c=[...st.daily,...st.weekly].find(x=>x.id===id); return !!(c&&c.done); })"
async def battle(pg, mode='quick'):
  await pg.evaluate("ABC_DEBUG.startBattle()"); await pg.wait_for_timeout(2500)
  await pg.evaluate(f"D=ABC_DEBUG; D.APP.mode='{mode}'; D.freeze(); D.busy=false; D.S.turn='you'; D.S.phase='strategize'; D.S.settings.triviaOn=false; D.S.you.attachesLeft=2; D.S.you.flags.bmCount=0; D.render()")
  await pg.wait_for_timeout(200)
GIVE="""((cat)=>{ const p=D.S.you; const pool=[...p.deck,...p.discard]; const c=pool.find(x=>x.cat===cat && (cat!=='crit'||x.fx!=='reader')); if(!c) return false; [p.deck,p.discard].forEach(z=>{ const i=z.indexOf(c); if(i>=0) z.splice(i,1); }); c._new=false; p.hand.unshift(c); D.render(); return true; })"""
PLAYBM="""(()=>{ const p=D.S.you; const pool=[...p.deck,...p.discard].filter(x=>x.cat==='bookmark');
  for(const c of pool){ [p.deck,p.discard].forEach(z=>{ const i=z.indexOf(c); if(i>=0) z.splice(i,1); }); c._new=false; p.hand.unshift(c); D.busy=false; D.render(); const n=(p.flags.bmCount||0); D.playBookmark('you',0);
    document.querySelectorAll('.modal-bg').forEach(m=>{ const b=m.querySelector('[data-pick],[data-val],button'); }); if((p.flags.bmCount||0)>n) return c.name; if(p.hand[0]===c) p.hand.shift(); }
  return null; })()"""
async def main():
  async with async_playwright() as p:
    b=await p.chromium.launch(**_launch_kw())
    res=[]; ok=lambda n,c: res.append(('PASS' if c else 'FAIL')+'  '+n)
    pg=await b.new_page(viewport={'width':1280,'height':720}); errs=[]; pg.on('pageerror',lambda e: errs.append(str(e)))
    await pg.goto(STUB_URL); await pg.wait_for_timeout(700)
    # determinism + structure
    a=await pg.evaluate("JSON.stringify(ABC_CH.state().daily.map(c=>c.id))")
    await pg.reload(); await pg.wait_for_timeout(700)
    b2=await pg.evaluate("localStorage.removeItem('abc_meta'); JSON.stringify(ABC_CH.state().daily.map(c=>c.id))")
    ok('same dailies on reload / fresh save (date-seeded)', a==b2)
    r=await pg.evaluate("""(()=>{ const C=ABC_CH; let bad=0, short=0; const d0=new Date(2026,9,26,12);
      for(let i=0;i<365;i++){ const d=new Date(d0.getTime()+i*864e5), k=d.getFullYear()+'-'+String(d.getMonth()+1).padStart(2,'0')+'-'+String(d.getDate()).padStart(2,'0'); const ids=C.dailies(k,[]);
        if(ids.length!==3) short++; const f=ids.map(id=>C.byId(id).fam), t=ids.map(id=>C.byId(id).tier).join(','); if(new Set(f).size!==3||t!=='easy,med,hard') bad++; }
      return {bad,short}; })()""")
    ok(f'a year of dailies: always Easy/Medium/Hard from 3 different families ({r})', r['bad']==0 and r['short']==0)
    r=await pg.evaluate("""(()=>{ const C=ABC_CH; let st=C.fresh(null,new Date(2026,9,26,10)); st.daily[0].done=true; C.claim(st,st.daily[0]);
      const s1=st.streak; st=C.fresh(st,new Date(2026,9,27,10)); const same=st.streak; st.daily[0].done=true; C.claim(st,st.daily[0]); const s2=st.streak;
      st=C.fresh(st,new Date(2026,9,29,10)); const broke=st.streak; const wk1=st.week; st=C.fresh(st,new Date(2026,10,2,10)); return {s1,same,s2,broke,wk1,wk2:st.week,claimedReset:st.bonusClaimed===false}; })()""")
    ok(f'streak grows on consecutive days and resets after a missed day ({r})', r['s1']==1 and r['same']==1 and r['s2']==2 and r['broke']==0)
    ok('weeklies roll over on Monday', r['wk1']!=r['wk2'] and r['claimedReset'])
    ok('menu shows the Challenges button', await pg.evaluate("!!document.querySelector('[data-do=go-challenges]')"))
    # ---- cards in one turn ladder through real plays ----
    await battle(pg)
    await pg.evaluate(FORCE, [['combo3','combo4','combo5'],['combo6','bm6','decks3']])
    for i in range(2):
      await pg.evaluate("D.busy=false; D.S.turn='you'; D.S.phase='strategize'; D.render()")
      await pg.evaluate("(()=>{ const p=D.S.you; const k=p.deck.findIndex(c=>c.cat==='abc'); p.hand.unshift(p.deck.splice(k,1)[0]); p.hand[0]._new=false; D.render(); D.tryPlayHandCard(0); })()"); await pg.wait_for_timeout(150)
    ok('2 ABC attaches counted as 2 plays', await pg.evaluate(P,'combo3')==2)
    n1=await pg.evaluate(PLAYBM); await pg.wait_for_timeout(100); n2=await pg.evaluate(PLAYBM); await pg.wait_for_timeout(100)
    ok(f'2 Bookmarks resolved ({n1}, {n2})', bool(n1 and n2))
    ok('Three-Card Trick completes', await pg.evaluate(DONE,'combo3'))
    ok('Four-Card Flourish completes', await pg.evaluate(DONE,'combo4'))
    ok('completion banner shows', await pg.evaluate("!!document.getElementById('abcChBanner')"))
    await pg.evaluate("D.busy=false; D.S.you.crit=null;"); await pg.evaluate(GIVE,'crit'); await pg.evaluate("D.playCrit('you',0)"); await pg.wait_for_timeout(100)
    ok('a Lens makes 5: Five-Card Frenzy completes', await pg.evaluate(DONE,'combo5'))
    ok(f'Full Hand at 5/6', await pg.evaluate(P,'combo6')==5)
    await pg.evaluate("D.busy=false; D.S.turn='opp'; D.endTurn()"); await pg.wait_for_timeout(200)
    await pg.evaluate("D.busy=false; D.S.turn='you'; D.S.phase='strategize'; D.S.you.attachesLeft=2; D.render()")
    await pg.evaluate("(()=>{ const p=D.S.you; const k=p.deck.findIndex(c=>c.cat==='abc'); p.hand.unshift(p.deck.splice(k,1)[0]); p.hand[0]._new=false; D.render(); D.tryPlayHandCard(0); })()"); await pg.wait_for_timeout(100)
    ok('new turn resets the per-turn count (Full Hand keeps its best)', await pg.evaluate("ABC_CH.scratch().turn.play")==1 and await pg.evaluate(P,'combo6')==5)
    ok('Bookmarks in one match carry across turns (2/6)', await pg.evaluate(P,'bm6')==2)
    # ---- trivia streak ----
    await pg.evaluate(FORCE, [['win1','streak5','perfect'],['triv25','untouch','boss1']])
    for i in range(5):
      await pg.evaluate("(()=>{ D.busy=false; D.S.turn='you'; D.S.phase='strategize'; D.S.settings.triviaOn=true; D.S.you.attachesLeft=2; const p=D.S.you; const k=p.deck.findIndex(c=>c.cat==='abc'); p.hand.unshift(p.deck.splice(k,1)[0]); p.hand[0]._new=false; D.render(); D.tryPlayHandCard(0); })()"); await pg.wait_for_timeout(120)
      await pg.evaluate("D.answerTrivia(D.S.pending.card.ans,true)"); await pg.wait_for_timeout(120)
    ok('5 correct answers in a row completes On a Roll', await pg.evaluate(DONE,'streak5'))
    ok('answers count toward Close Reader (5/25)', await pg.evaluate(P,'triv25')==5)
    await pg.evaluate("(()=>{ D.busy=false; D.S.turn='you'; D.S.phase='strategize'; D.S.you.attachesLeft=2; const p=D.S.you; const k=p.deck.findIndex(c=>c.cat==='abc'); p.hand.unshift(p.deck.splice(k,1)[0]); p.hand[0]._new=false; D.render(); D.tryPlayHandCard(0); })()"); await pg.wait_for_timeout(120)
    await pg.evaluate("D.answerTrivia((D.S.pending.card.ans+1)%4,true)"); await pg.wait_for_timeout(120)
    ok('a wrong answer breaks the streak', await pg.evaluate("ABC_CH.scratch().ansStreak")==0)
    # ---- KO from full HP in one turn, KO counts ----
    await pg.evaluate(FORCE, [['ko2','ko3','oneturn'],['untouch','decks3','bm6']])
    await pg.evaluate("D.busy=false; D.S.turn='opp'; const o=D.S.opp.team[D.S.opp.activeIdx]; o.hp=o.maxHp; D.endTurn()"); await pg.wait_for_timeout(200)
    await pg.evaluate("document.querySelectorAll('.modal-bg').forEach(m=>m.remove()); const o=D.S.opp.team[D.S.opp.activeIdx]; o.hp=0; D.checkKO(D.S.opp,'opp')"); await pg.wait_for_timeout(200)
    ok('KO of a full-HP character this turn completes In One Stroke', await pg.evaluate(DONE,'oneturn'))
    ok('KO counted (1/2)', await pg.evaluate(P,'ko2')==1)
    # ---- win, deck variety, untouchable ----
    await pg.evaluate("document.querySelectorAll('.modal-bg').forEach(m=>m.remove()); D.S.over=true; D.S.winner='you'; D.render()"); await pg.wait_for_timeout(200)
    ok('a win counts once toward Wide Reader (1/3)', await pg.evaluate(P,'decks3')==1)
    await pg.evaluate("D.render(); D.render()"); await pg.wait_for_timeout(100)
    ok('repaints of the result screen do not double-count', await pg.evaluate(P,'decks3')==1)
    ok('won without your Active KO\'d: Untouchable completes', await pg.evaluate(DONE,'untouch'))
    # ---- Siphon drains (distinct enemies) ----
    await battle(pg)
    await pg.evaluate(FORCE, [['win1','ko3','oneturn'],['siphon3','decks3','bm6']])
    await pg.evaluate("D.busy=false; D.S.turn='you'; const o=D.S.opp.team[D.S.opp.activeIdx]; o.status={siphon:{amt:10,turns:3,leech:5,mode:'hp',own:{side:'you',idx:D.S.you.activeIdx}}}; D.endTurn()"); await pg.wait_for_timeout(300)
    ok('a Siphon drain on an enemy counts (1/3)', await pg.evaluate(P,'siphon3')==1)
    await pg.evaluate("D.busy=false; D.S.turn='you'; D.endTurn()"); await pg.wait_for_timeout(300)
    ok('the same enemy again does not count twice', await pg.evaluate(P,'siphon3')==1)
    # ---- statuses + thesis through real attacks / Lens ----
    await battle(pg)
    await pg.evaluate(FORCE, [['stat2','thesis1','combo5'],['bm6','decks3','untouch']])
    for k in ['burn','tear']:
      await pg.evaluate(f"""(()=>{{ D.busy=false; D.S.turn='you'; D.S.phase='engage'; const c=D.S.you.team[D.S.you.activeIdx]; c.status={{}}; c.atk=Object.assign({{}},c.atk,{{inflict:'{k}',cost:1,dmg:1}}); c.atkCharge=[{{type:'ATTACK',power:1,cid:'x{k}'}}]; const o=D.S.opp.team[D.S.opp.activeIdx]; o.status={{}}; o.blkCharge=[]; o.hp=o.maxHp; D.S.you.flags.attacked=false; D.render(); }})()""")
      await pg.wait_for_timeout(100); await pg.click('.you-side .pc-move[data-act="attack"]'); await pg.wait_for_timeout(1500)
      await pg.evaluate("document.querySelectorAll('.modal-bg').forEach(m=>m.remove())")
    ok('two different statuses inflicted by attacks: Marginalia completes', await pg.evaluate(DONE,'stat2'))
    await pg.evaluate("D.busy=false; D.S.you.crit=null;"); await pg.evaluate(GIVE,'crit'); await pg.evaluate("D.S.turn='you'; D.S.phase='strategize'; D.playCrit('you',0); D.fulfillThesis('you')"); await pg.wait_for_timeout(150)
    ok('fulfilling a thesis completes Thesis Defended', await pg.evaluate(DONE,'thesis1'))
    # ---- eligibility ----
    await battle(pg)
    await pg.evaluate(FORCE, [['combo3','ko3','combo5'],['bm6','decks3','untouch']])
    for mode,setup,label in [('custom','','Custom Play'),('quick',"D.S._sim=true;",'AI-vs-AI sim'),('quick',"D.S._sim=false; D.S.settings.maxAttaches=3; D.S.you.attachesLeft=3;",'non-standard rules (3 attaches)')]:
      await pg.evaluate(f"D.APP.mode='{mode}'; {setup} D.busy=false; D.S.turn='you'; D.S.phase='strategize'; D.S.settings.triviaOn=false; D.S.you.attachesLeft=Math.max(D.S.you.attachesLeft,1); const p=D.S.you; const k=p.deck.findIndex(c=>c.cat==='abc'); p.hand.unshift(p.deck.splice(k,1)[0]); p.hand[0]._new=false; D.render(); D.tryPlayHandCard(0);")
      await pg.wait_for_timeout(120)
      ok(f'{label} does not count', await pg.evaluate(P,'combo3')==0)
    await pg.evaluate("D.S.settings.maxAttaches=2; D.APP.mode='quick'")
    # ---- claim / swap / bonus on the screen ----
    await pg.evaluate("D.APP.screen='menu'; D.render()")
    st0=await pg.evaluate("ABC_DEBUG.META.ip||0")
    await pg.evaluate(FORCE, [['win1','ko3','combo5'],['bm6','decks3','untouch']])
    await pg.evaluate("(()=>{ const st=ABC_CH.state(); st.daily[0].p=1; st.daily[0].done=true; st.weekly.forEach(c=>{ c.p=c.n||1; c.done=true; }); })()")
    await pg.evaluate("ABC_DEBUG.render()"); await pg.wait_for_timeout(100)
    ok('menu badge shows claimable count', await pg.evaluate("(document.querySelector('[data-do=go-challenges] .chs-badge')||{}).textContent==='4'"))
    await pg.click('[data-do=go-challenges]'); await pg.wait_for_timeout(200)
    await pg.click('[data-do="ch-claim:d0"]'); await pg.wait_for_timeout(150)
    ok('claiming a daily pays 8 IP and starts the streak', await pg.evaluate("ABC_DEBUG.META.ip||0")==st0+8 and await pg.evaluate("ABC_CH.state().streak")==1)
    await pg.click('[data-do="ch-swap:1"]'); await pg.wait_for_timeout(150)
    ok('one swap per day (swap link gone after use)', await pg.evaluate("ABC_CH.state().daily[1].id")!='ko3' and not await pg.evaluate("!!document.querySelector('[data-do^=\"ch-swap\"]')"))
    for i in range(3): await pg.click(f'[data-do="ch-claim:w{i}"]'); await pg.wait_for_timeout(120)
    ok('three weeklies pay 120 IP', await pg.evaluate("ABC_DEBUG.META.ip||0")==st0+8+120)
    pk0=await pg.evaluate("ABC_DEBUG.META.packs||0")
    await pg.click('[data-do=ch-bonus]'); await pg.wait_for_timeout(600)
    r=await pg.evaluate("({ovl:!!document.querySelector('.pkr-ovl.show'), packs:ABC_DEBUG.META.packs||0, ip:ABC_DEBUG.META.ip||0, done:ABC_CH.state().bonusClaimed})")
    ok(f'weekly bonus opens a free Silver pack, no IP spent ({r})', r['ovl'] and r['packs']==pk0+1 and r['ip']>=st0+128 and r['done'])
    ok('progress saved in the save file', await pg.evaluate("!!JSON.parse(localStorage.getItem('abc_meta')||'{}').challenges"))
    ok('no page errors', not errs)
    print('\n'.join(res)); print(sum(r.startswith('PASS') for r in res),'/',len(res)); globals()['_FAILS']=sum(r.startswith('FAIL') for r in res); await b.close()
asyncio.run(main())
import sys; sys.exit(1 if globals().get('_FAILS') else 0)
